/*
	objects.h contains the prototypes of all types of objects and the parent object class. Details can be found
	in objects.cpp.
*/

#ifndef OBJECTS_H
#define OBJECTS_H

#include "ray.h"
#include <vector>

struct Colour{
	Point col;//holds three values between 0 and 255 to represent the base colour
	Point ambient;//holds three values between 0 and 1 as the ambient coefficients for light computation
	Point diffuse;//holds three values between 0 and 1 as the diffuse coefficients for light computation
	Point specular;//holds three values between 0 and 1 as the specular coefficients for light computation
	
	int specPower;//holds the exponent of cos in the specular light computation
	float reflectPower;// between 0 and 1
	
	Colour();
	Colour(Point c, Point amb, Point dif, Point spec, int specPow, float refPow);
};

class Object{
public:
	Colour clr;//hold the colour of the object

	virtual bool Intersection(Ray r, float& t) = 0;
	virtual Ray Normal(Point p) = 0;
};

class Sphere : public Object{
public:
	Point centre;//centre of the sphere
	float radius;//radius of the sphere
	
	Sphere();
	Sphere(Point cen, float r, Colour col);
	virtual bool Intersection(Ray r, float& t);
	virtual Ray Normal(Point p);
};

class Plane : public Object{
public:
	Point p;//point in the plane
	Ray n;//a vector normal to the plane
	
	Plane();
	Plane(Point pnt, Ray norm, Colour col);
	virtual bool Intersection(Ray r, float& t);
	virtual Ray Normal(Point p);
};

class Triangle : public Object{
public:
	Point a, b, c;//the three points that define the verticies of the triangle (counter-clockwise order)
	
	Triangle();
	Triangle(Point a1, Point b1, Point c1, Colour col);
	virtual bool Intersection(Ray r, float& t);
	virtual Ray Normal(Point p);
};

class Rectangle : public Object{
public:
	Point a, b, c, d;
	Triangle f1;
	Triangle f2;
	//std::vector<Triangle *> Mesh;
	//Triangle Mesh[2];

	Rectangle();
	Rectangle(Point a1, Point b1, Point c1, Point d1, Colour col);
	virtual bool Intersection(Ray r, float& t);
	virtual Ray Normal(Point p);
};

class Box : public Object{
public:
	Point a, b;
	std::vector<Triangle *> Mesh;

	Box();
	Box(Point a1, Point b1, Colour col);
	virtual bool Intersection(Ray r, float& t);
	virtual Ray Normal(Point p);
};

#endif
