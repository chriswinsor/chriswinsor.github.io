/*
	objects.cpp implements all constructors and functions for the variety of solids to be included
	in the scene of the raytracer. Each object is a subclass of parent Object which requires two 
	functions; Intersect which returns true if the provided ray intersects with the object, and 
	Normal which returns the surface normal at a given point on the object.
	
	Objects included:

		Sphere: A sphere defined by a centre point and a radius

		Plane: A plane defined by a point on the plane and the normal vector of the plane

		Triangle: A triangle defined by three points in a counter-clockwise manner. (order of points matter)
*/

#include "objects.h"
#include "math.h"
#include <stdio.h>
#include <vector>
#include "ray.h"

//basic constructor for a Colour
Colour::Colour(){
	col.Set(200, 200, 200);
	ambient.Set(0.2, 0.2, 0.2);
	diffuse.Set(0.2, 0.2, 0.2);
	specular.Set(0.7, 0.7, 0.7);
	
	specPower = 50;
	reflectPower = 0;
}

//secondary constructor for colour that initiates each variable
Colour::Colour(Point c, Point amb, Point dif, Point spec, int specPow, float refPow){
	col.Copy(c);
	ambient.Copy(amb);
	diffuse.Copy(dif);
	specular.Copy(spec);
	
	specPower = specPow;
	reflectPower = refPow;
}

//basic constructor for a Sphere
Sphere::Sphere(){
	centre = Point(0,0,0);
	radius = 1;
	
	clr = Colour();
}

//secondary constructor that initalizes all variables
Sphere::Sphere(Point cen, float r, Colour col){
	centre.Copy(cen);
	radius = r;
	
	clr = col;
};

//returns true if the ray intersects it and the t such that r.o + t*r.d intersects the sphere
bool Sphere::Intersection(Ray r, float& t){
	Ray OC(centre,r.o);
	
	//finds the A, B, C such that At^2 + Bt + C = 0 and sets t1 and t2 to be the roots from the quad formula
	float A = r.Dot(r);
	float B = 2*(r.Dot(OC));
	float C = OC.Dot(OC) - (radius*radius);
	float t1 = (-B + sqrt((B*B)-(4*A*C)))/(2*A);
	float t2 = (-B - sqrt((B*B)-(4*A*C)))/(2*A);
	
	//returns true with the smallest positive root and false if both are negative
	if (t1 > 1.0e-5 && t2 > 1.0e-5){
		t = t2;
		return true;
	}
	else if (t1 > 1.0e-5){
		t = t1;
		return true;
	}
	else{
		t = -1;
		return false;
	}
}

//returns a surface normal ray at point p
Ray Sphere::Normal(Point p){
	Ray temp(centre, p);
	temp.Normalize();
	return temp;
}

//basic constructor for a Plane
Plane::Plane(){
	p = Point(0,0,0);
	n = Ray(p,Point(1,0,0));
	clr = Colour();
}

//secondary constructor that initalizes all variables
Plane::Plane(Point pnt, Ray norm, Colour col){
	p.Copy(pnt);
	n = norm;
	clr = col;
}

//returns true if the ray intersects it and the t such that r.o + t*r.d intersects the plane
bool Plane::Intersection(Ray r, float& t){

	float denominator = n.Dot(r);//computes the denominator of the equation solved for t
	
	//insures we arn't dividing by zero
	if (abs(denominator) > 0){
		Ray PO(r.o, p);
		float t1 = (PO.Dot(n)) / denominator;

		//returns true if t is positive(not behind the camera)
		if (t1 >= 0){
			t = t1;
			return true;
		}
	}
	t = -1;
	return false;
}

//returns a surface normal ray at point p
Ray Plane::Normal(Point p){
	return n;
}

//basic constructor for a Triangle
Triangle::Triangle(){
	a = Point(1,0,0);
	b = Point(0,1,0);
	c = Point(0,0,1);
	clr = Colour();
}

//secondary constructor that initalizes all variables
Triangle::Triangle(Point a1, Point b1, Point c1, Colour col){
	a.Copy(a1);
	b.Copy(b1);
	c.Copy(c1);
	clr = col;
}

//returns true if the ray intersects it and the t such that r.o + t*r.d intersects the triangle
bool Triangle::Intersection(Ray r, float& t){
	//gets the normal vector
	Ray AB(b, a);
	Ray AC(c, a);
	Ray n = AB.Cross(AC);
	n.Normalize();

	//checks if ray is parallel to the triangle
	if (abs(n.Dot(r)) < 1.0e-5){
		return false;
	}

	//computes the ray/plane intersection
	float D = n.Dot(Ray(Point(0, 0, 0), a));
	float t1 = -(n.Dot(Ray(Point(0, 0, 0), r.o)) + D) / (n.Dot(r));

	if (t1 < 1.0e-5) return false;//returns false if intersection is behind the camera

	//computes the intersection point
	Point p(0, 0, 0);
	p.Copy(r.d);
	p.Scalar(t1);
	p.Add(r.o);
	
	//tests if the point is inside the triangle and returns false it it fails any edge test
	Ray edgeTest;
	Ray BA(a, b);
	Ray PA(a, p);
	edgeTest = BA.Cross(PA);
	if (n.Dot(edgeTest) < 0) return false;

	Ray CB(b, c);
	Ray PB(b, p);
	edgeTest = CB.Cross(PB);
	if (n.Dot(edgeTest) < 0) return false;

	Ray CA(c, a);
	Ray PC(c, p);
	edgeTest = CA.Cross(PC);
	if (n.Dot(edgeTest) < 0) return false;

	//finally sets t since it passes all tests and returns true
	t = t1;
	return true;
}

//returns a surface normal ray at point p
Ray Triangle::Normal(Point p){
	Ray AB(b, a);
	Ray AC(c, a);
	return AB.Cross(AC);
}

Rectangle::Rectangle(){
	a.Copy(Point(200, 200, 0));
	b.Copy(Point(100, 100, 0));

	/*std::vector<Triangle *> MeshTemp;
	Triangle f1(Point(200, 200, 0), Point(200, 100, 0), Point(100, 200, 0), Colour());
	Triangle f2(Point(100, 200, 0), Point(200, 100, 0), Point(100, 100, 0), Colour());
	MeshTemp.push_back(&f1);
	MeshTemp.push_back(&f2);
	Mesh = MeshTemp;*/
	//Mesh[0] = f1;
	//Mesh[1] = f2;
	clr = Colour();
}

Rectangle::Rectangle(Point a1, Point b1, Point c1, Point d1, Colour col){
	a.Copy(a1);
	b.Copy(b1);
	c.Copy(c1);
	d.Copy(d1);
	f1 = Triangle(a,b, c, Colour());
	f2 = Triangle(c, d, a, Colour());
	//MeshTemp.push_back(&f1);
	//MeshTemp.push_back(&f2);
	//Mesh = MeshTemp;
	//Mesh[0] = f1;
	//Mesh[1] = f2;
	clr = col;
}

bool Rectangle::Intersection(Ray r, float& t){
	Ray temp(r.o, r.d);
	std::vector<Triangle *> MeshTemp;
	//Triangle f1(a, Point(a.x, a.y - b.y, 0), Point(a.x - b.x, a.y, 0), Colour());
	//Triangle f2(Point(a.x - b.x, a.y, 0), Point(a.x, a.y - b.y, 0), b, Colour());
	MeshTemp.push_back(&f1);
	MeshTemp.push_back(&f2);
	//check for intersection with r
	for (int k = 0; k < 2; ++k){
		float t1 = -1;//holds the place r intersects with object k
		//bool hasIntersection = Mesh[k]->Intersection(r, t1);//checks if there is an intersection with object k
		if (MeshTemp[k]->Intersection(temp, t1)){
			if (t1 > 1.0e-5){
				t = t1;
				return true;
			}
		}
	}
	return false;
}

Ray Rectangle::Normal(Point p){
	return f1.Normal(p);
}