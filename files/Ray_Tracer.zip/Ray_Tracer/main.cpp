
#include <string.h>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <vector>

#include "ray.h"
#include "objects.h"
#include "light.h"
#include "raytrace.h"
#include "Image.h"


int main(int,char**){
	int imageSize = 512;
	Image image(imageSize, imageSize);

	Point camera(imageSize / 2, imageSize / 2, -400);//camera's position
	
	//light source's position
	Point lightSource(0, 0, -200);
	Point lightSource2(512, 0, -200);
	Point lightSource3(imageSize / 2, imageSize / 2, -100);

	Point lights[] = { lightSource, lightSource2, lightSource3 };
	int lightsSize = 3;

	float intensities[] = { 0.3333, 0.3333, 0.3333 };

	//creates all the objects in the scene
	std::vector<Object *> objects;
	Sphere s1(Point(256, 400, 250), 100, Colour());
	Sphere s2(Point(256, 200, 250), 100, Colour());
	Plane s3(Point(imageSize, imageSize, 0), Ray(Point(imageSize, imageSize, 0), Point(imageSize, imageSize - 1, 0)), Colour());
	Plane s4(Point(imageSize, imageSize, 0), Ray(Point(imageSize, imageSize, 0), Point(imageSize - 1, imageSize, 0)), Colour());
	Plane s5(Point(0, 0, 0), Ray(Point(0, 0, 0), Point(1, 0, 0)), Colour());
	Plane s6(Point(0, 0, 512), Ray(Point(0, 0, 0), Point(0, 0, -1)), Colour());
	Plane s7(Point(0, 0, 0), Ray(Point(0, 0, 0), Point(0, 1, 0)), Colour());
	Triangle s8(Point(200, 200, 0), Point(200, 100, 0), Point(100, 200, 0), Colour());
	Triangle s9(Point(100, 200, 0), Point(200, 100, 0), Point(100, 100, 0), Colour());
	//Rectangle s8(Point(100, 100, 0), Point(200, 100, 0), Point(200, 200, 0), Point(100, 200, 0), Colour());

	//pushes the object into the list
	objects.push_back(&s1);
	objects.push_back(&s2);
	objects.push_back(&s3);
	objects.push_back(&s4);
	objects.push_back(&s5);
	objects.push_back(&s6);
	objects.push_back(&s7);
	//objects.push_back(&s8);
	//objects.push_back(&s9);

	//s1.clr.reflectPower = 0.1;
	s4.clr.col.Set(255, 200, 240);

	//iterates through each pixle
	for (int i = 0; i < imageSize; ++i){
		for (int j = 0; j < imageSize; ++j){

			//super sampling X4
			Pixel px;
			Point colour(0, 0, 0);
			Point direction1 = Point(j + 0.7, i + 0.7, 0);
			Ray r1 = Ray(camera, direction1);//casted ray
			r1.Normalize();

			Point direction2 = Point(j + 0.7, i - 0.7, 0);
			Ray r2 = Ray(camera, direction2);//casted ray
			r2.Normalize();

			Point direction3 = Point(j - 0.7, i + 0.7, 0);
			Ray r3 = Ray(camera, direction3);//casted ray
			r3.Normalize();

			Point direction4 = Point(j - 0.7, i - 0.7, 0);
			Ray r4 = Ray(camera, direction4);//casted ray
			r4.Normalize();

			Ray r[] = { r1, r2, r3, r4 };
			for (int k = 0; k < 4; ++k){
				//Point direction = Point(j, i, 0);
				//Ray r = Ray(camera, direction);//casted ray
				//r.Normalize();
				int depth = 0;
				colour.Add(rayTrace(r[k], camera, lights, lightsSize, intensities, objects, depth));
			}
			colour.Scalar(0.25);
			setColour(px, colour);
			image(i,j) = px;
		}
	}
	image.save("Test.png");
}