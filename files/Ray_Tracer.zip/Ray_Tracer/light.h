/*
	light.h contains all functions to do with computing the seperate light type colour 
	contributions and setting the final pixle colour with the sum of the colour types.
*/

#pragma once

#include "objects.h"
#include "ray.h"
#include "Image.h"
#include <algorithm>
#include <math.h>

//computes the diffuse light contribution of the colour (Lambertian model)
//I is the light intensity, c is the colour, l is the ray to lightsource, n is the normal vector
Point diffuseComp(float I, Colour c, Ray l, Ray n){
	Point Ld;
	Ld.Copy(c.diffuse);//places in diffuse coefficient

	//multiplies by the cosine of the angle
	float constent = I*std::max(0.0f, l.Dot(n));
	Ld.Scalar(constent);

	Ld.Mult(c.col);//multiplies everything by the base colour to get the diffuse percent
	return Ld;
}

//computes the ambient light contribution of the colour 
//I is the light intensity, c is the colour
Point ambientComp(float I, Colour c){
	Point La;
	La.Copy(c.ambient);//places in ambient coefficient
	La.Scalar(I);//adjusts intensity
	La.Mult(c.col);//multiplies everything by the base colour to get the ambient percent
	return La;
}

//computes the specular light contribution of the colour (Phong model)
//I is the light intensity, c is the colour, l is the ray to lightsource, n is the normal vector, v is the vector to the camera
Point specularComp(float I, Colour c, Ray l, Ray n, Ray v){
	Point Ls;
	Ls.Copy(c.specular);//places in specular coefficient
	
	//computes l v bisector
	Point end;
	end.Copy(v.d);
	end.Add(l.d);
	Ray h(Point(0, 0, 0),end);
	h.Normalize();

	//multiply by the cosine of n and h to the power of specpower
	float constent = I*pow(std::max(0.0f, n.Dot(h)), c.specPower);
	Ls.Scalar(constent);
	
	Ls.Mult(c.col);//multiplies everything by the base colour to get the specular percent
	return Ls;
}

//sets the pixel colour to c
void setColour(Pixel & px, Point c){
	if (c.x < 0) px.R = 0;
	else if (c.x > 255) px.R = 255;
	else px.R = (unsigned char)c.x;

	if (c.y < 0) px.G = 0;
	else if (c.y > 255) px.G = 255;
	else px.G = (unsigned char)c.y;

	if (c.z < 0) px.B = 0;
	else if (c.z > 255) px.B = 255;
	else px.B = (unsigned char)c.z;

	px.A = 255;
}

//gives the pixel the colour of the sum of the different light contributions
Point shade(float I, Colour c, Ray light, Ray norm, Ray r){
	Point clr(0, 0, 0);

	Point diffuseColour = diffuseComp(I, c, light, norm);
	Point ambientColour = ambientComp(I, c);
	Point specularColour = specularComp(I, c, light, norm, r);
	clr.Add(diffuseColour);
	clr.Add(ambientColour);
	clr.Add(specularColour);
	return clr;
}