/*
	ray.h contains the prototypes of Point and Ray. Details on both can be found 
	in ray.cpp.
*/

#ifndef RAY_H
#define RAY_H

struct Point{
	//x, y, z are the three coordinates of the point
	float x,y,z;
	
	//constructors
	Point();
	Point(float x_in, float y_in, float z_in);
	
	//functions
	void Set(float x_in, float y_in, float z_in);
	void Add(Point p);
	void Minus(Point);
	void Minus(Point p1, Point p2);
	void Scalar(float t);
	void Mult(Point p);
	void Copy(Point p);
};

struct Ray{
	//o is the origin of the ray and d is the direction vector of the ray
	Point o, d;
	
	//constructors
	Ray();
	Ray(Point str, Point end);
	
	//functions
	float Modulus();
	void Scalar(float t);
	void Normalize();
	float Dot(Ray r1);
	Ray Cross(Ray r);
};

#endif
