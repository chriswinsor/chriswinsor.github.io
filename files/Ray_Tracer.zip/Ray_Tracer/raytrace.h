
#include <stdlib.h>
#include <stdio.h>
#include <vector>

#include "ray.h"
#include "objects.h"
#include "light.h"
#include "Image.h"


Point rayTrace(Ray r, Point camera, Point lights[], int lightsSize, float intensities[], std::vector<Object *> objects, int depth){

	Point backgroundColour(100, 200, 255);//defult colour of scene

	r.Normalize();

	//holds the information about the closest intersection
	float min_t = 999999;
	float min_k = 0;
	bool intersects = false;

	//check for minimum object intersection with r
	for (int k = 0; k < objects.size(); ++k){

		float t = 999999;//holds the place r intersects with object k
		bool hasIntersection = objects[k]->Intersection(r, t);//checks if there is an intersection with object k

		//if there is an intersection, check if it is a new minimum
		if (hasIntersection){
			if (min_t > t && t > 1.0e-5){
				intersects = true;
				min_t = t;
				min_k = k;
			}
		}
	}

	//if there is an intersection, computes the colour of the pixel
	if (intersects){
		//computes intersection point
		Point inter(0, 0, 0);
		inter.Copy(r.d);
		inter.Scalar(min_t);
		inter.Add(camera);
		inter.Add(Point(0, 0, -0.005));//small offset to prevent intersecting with its self

		Point colour(0, 0, 0);//holds the final colour

		for (int l = 0; l < lightsSize; ++l){
			//computes the rays needed for computing the light components
			Ray light = Ray(inter, lights[l]);
			light.Normalize();
			Ray norm = objects[min_k]->Normal(inter);
			norm.Normalize();
			Ray v(inter, camera);
			v.Normalize();

			Ray reflection = objects[min_k]->Normal(inter);
			float c1 = v.Dot(norm);
			reflection.Scalar(2*c1);
			reflection.d.Add(v.d);

			if (objects[min_k]->clr.reflectPower > 1.0e-5 && depth < 4){
				++depth;
				Point reflectColour = rayTrace(reflection, camera, lights, lightsSize, intensities, objects, depth);
				reflectColour.Scalar(objects[min_k]->clr.reflectPower);
				colour.Add(reflectColour);
			}
			else{
				bool hasIntersection = false;//stays false if not in shadow
				Point p;
				p.Minus(lights[l], inter);
				Ray dist(Point(0, 0, 0), p);

				//checks if object is in shadow
				for (int k = 0; k < objects.size(); ++k){
					float t = -1;
					if (objects[k]->Intersection(light, t)){
						//checks if positive and not behind light source
						if (t > 0 && t < sqrt(dist.Dot(dist)) - 1.0e-1){
							//gives the pixel the objects ambient colour if it intersects
							colour.Add(ambientComp(intensities[l], objects[min_k]->clr));
							//colour.Copy(ambientComp(intensities[l], objects[min_k]->clr));
							hasIntersection = true;
						}
						break;
					}
				}
				//gives the pixle the object colour since not in shadow
				if (!hasIntersection){
					colour.Add(shade(intensities[l], objects[min_k]->clr, light, norm, v));
				}
			}
		}
		return colour;
	}
	return backgroundColour;
}