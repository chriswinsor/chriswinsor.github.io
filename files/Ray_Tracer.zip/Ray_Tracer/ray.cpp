/*
	ray.cpp implements all constructors and functions for both the Ray class and the Point class
	outlined in ray.h. The Ray class implements the parametric form of a vector and a variety of
	the basic vector calculations. The Point class implements a 3D point to differentiate between
	points and vectors(Rays). Point includes a viriety of basic arithmatic operations to help with
	calculations using points.
*/


#include "ray.h"
#include "math.h"
#include <string.h>
#include <stdio.h>

//basic constructor for a Ray
Ray::Ray(){
	o.Set(0, 0, 0);
	d.Set(0, 0, 1);
};

//secondary constructor calculates the vector between two points
Ray::Ray(Point str,Point end){
	o.Copy(str);
	d.Minus(end, str);
}

//returns the modulus of the ray
float Ray::Modulus(){
	return sqrt(((d.x)*(d.x)) + ((d.y)*(d.y)) + ((d.z)*(d.z)));
}

//scalar multiplies a ray by given constent t
void Ray::Scalar(float t){
	d.x *= t;
	d.y *= t;
	d.z *= t;
}

//normalizes the direction of the ray
void Ray::Normalize(){
	float mod = Modulus();
	
	d.x /= mod;
	d.y /= mod;
	d.z /= mod;
}

//returns the dot product of the ray with a given ray r1
float Ray::Dot(Ray r1){
	float dot = 0;
	
	dot += d.x*r1.d.x;
	dot += d.y*r1.d.y;
	dot += d.z*r1.d.z;
	
	return dot;
}

//returns a Ray containing the cross product of the ray with a given ray r
Ray Ray::Cross(Ray r){
	Point start(0, 0, 0);
	Point end(((d.y*r.d.z)-(d.z*r.d.y)), ((d.z*r.d.x)-(d.x*r.d.z))
		,((d.x*r.d.y)-(d.y*r.d.x)));
	Ray c = Ray(start,end);
	
	return c;
}

//basic constructor for a Point
Point::Point(){
	x = 0;
	y = 0;
	z = 0;
}

//secondary constructor that sets the points coordinates to the ones inputed
Point::Point(float x_in, float y_in, float z_in){
	x = x_in;
	y = y_in;
	z = z_in;
}

//sets the points coordinates to the ones inputed
void Point::Set(float x_in, float y_in, float z_in){
	x = x_in;
	y = y_in;
	z = z_in;
}

//adds the values of a point p to this point
void Point::Add(Point p){
	x += p.x;
	y += p.y;
	z += p.z;
}

//subtracts the values of a point p from this point
void Point::Minus(Point p){
	x -= p.x;
	y -= p.y;
	z -= p.z;
}

//sets the points coordinates to p1 minus p2
void Point::Minus(Point p1, Point p2){
	x = p1.x - p2.x;
	y = p1.y - p2.y;
	z = p1.z - p2.z;
}

//scalar multiplies the point by given constent t
void Point::Scalar(float t){
	x *= t;
	y *= t;
	z *= t;
}

//multiplies the coordinates of the point by the coresponding coordinates in p
void Point::Mult(Point p){
	x *= p.x;
	y *= p.y;
	z *= p.z;
}

//coppies the contents of the point p into this point
void Point::Copy(Point p){
	x = p.x;
	y = p.y;
	z = p.z;
}

