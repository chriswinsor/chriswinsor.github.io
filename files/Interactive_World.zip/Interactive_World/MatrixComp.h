#pragma once

using namespace glm;

//tested
mat4 morthComp(vec3 lbn, vec3 rtf){
	mat4 m = mat4();
	/*for (int i = 0; i < m.length(); ++i){
		for (int j = 0; j < m.length(); ++j){
			if (i == j){
				if (i == 3){
					m[i][j] = 1;
				}
				else if (i == 2){
					m[i][j] = (float)2 / (float)(lbn[i] - rtf[i]);
				}
				else{
					m[i][j] = (float)2 / (float)(rtf[i] - lbn[i]);
				}
			}
			else{
				m[i][j] = 0;
			}
		}
	}*/
	m[0][0] = (float)2 / (float)(rtf[0] - lbn[0]);
	m[0][3] = -1 * (float)(rtf[0] + lbn[0]) / (float)(rtf[0] - lbn[0]);
	m[1][1] = (float)2 / (float)(rtf[1] - lbn[1]);
	m[1][3] = -1 * (float)(rtf[1] + lbn[1]) / (float)(rtf[1] - lbn[1]);
	m[2][2] = (float)2 / (float)(lbn[2] - rtf[2]);
	m[2][3] = -1 * (float)(lbn[2] + rtf[2]) / (float)(lbn[2] - rtf[2]);

	return m;
}
//tested
mat4 mcamComp(vec3 g, vec3 up, vec3 e){

	vec3 w = -g;
	w = normalize(w);
	vec3 u = cross(up, w);
	u = normalize(u);
	vec3 v = cross(w, u);

	mat4 m = mat4();
	for (int i = 0; i<3; ++i){
		m[0][i] = u[i];
		m[1][i] = v[i];
		m[2][i] = w[i];
	}

	mat4 m2 = mat4();
	for (int i = 0; i<3; ++i){
		m2[i][3] = -e[i];
		m2[3][i] = 0;
	}
	return m*m2;
}
//tested
mat4 mpComp(float n, float f){
	mat4 m = mat4();
	/*for (int i = 0; i < m.length(); ++i){
		for (int j = 0; j < m.length(); ++j){
			if (i == j && i != 3){
				m[i][j] = n;
			}
			else{
				m[i][j] = 0;
			}
		}
	}*/
	m[0][0] = n;
	m[1][1] = n;
	m[2][2] = (n + f);
	m[3][2] = 1;
	m[2][3] = -f * n;
	m[3][3] = 0;

	return m;
}
/*
mat4 rotX(float theta){
	mat4 r = mat4();
	r(1, 1) = cos(theta);
	r(1, 2) = sin(theta);
	r(2, 1) = -1 * sin(theta);
	r(2, 2) = cos(theta);
	return r;
}

mat4 rotY(float theta){
	mat4 r = mat4();
	r(0, 0) = cos(theta);
	r(0, 2) = sin(theta);
	r(2, 0) = -1 * sin(theta);
	r(2, 2) = cos(theta);
	return r;
}

mat4 rotZ(float theta){
	mat4 r = mat4();
	r(0, 0) = cos(theta);
	r(0, 1) = sin(theta);
	r(1, 0) = -1 * sin(theta);
	r(1, 1) = cos(theta);
	return r;
}

Matrix4f rotVert(float theta, Vector3f p){
	Matrix4f r(Matrix4f::Identity());
	Matrix3f temp;
	temp = AngleAxisf(theta, p.cross(Vector3f::UnitY()).normalized());
	r.block<3, 3>(0, 0) = temp;
	return r;
}

mat4 rotHoriz(float theta, vec3 p){
	mat4 r(Matrix4f::Identity());
	mat3 temp;
	temp = AngleAxisf(theta, p.cross(Vector3f::UnitX()).normalized());
	r.block<3, 3>(0, 0) = temp;
	return r;
}*/

mat4 scale1(float l){
	mat4 r = mat4(l);
	//r.diagonal().fill(l);
	r[3][3] = 1;
	return r;
}

//tested
void printMat(mat4 m){
	for (int i = 0; i < m.length(); ++i){
		for (int j = 0; j < m.length(); ++j){
			printf("%f ", m[i][j]);
		}
		printf("\n");
	}
	printf("\n");
}

