
using namespace glm;

unsigned int seed = 160;//seed for the random numbers

//creates the 2D grid
const int size = 256;
float grid[size + 1][size + 1];
GLfloat vPoint7[(size + 1) * (size + 1) * 9 * 6];

//returns a random number between -1 and 1
float getRand(){
	float f = rand() % 1000 - 500;
	f /= 500;

	return f;
}

//runs a recursive version of the diamond square algorithm
void diamondSquare(int startX, int startY, int endX, int endY, float range, int level){
	if (level < 1) return;//stops the recursion after enough subdivisions

	//diamond part
	for (int i = startX + level; i < endX; i += level){
		for (int j = startY + level; j < endY; j += level){
			float a = grid[i - level][j - level];
			float b = grid[i][j - level];
			float c = grid[i - level][j];
			float d = grid[i][j];

			grid[i - level / 2][j - level / 2] = (a + b + c + d) / 4 + getRand() * range;
		}
	}

	//square part
	for (int i = startX + 2 * level; i < endX; i += level){
		for (int j = startY + 2 * level; j < endY; j += level){
			float a = grid[i - level][j - level];
			float b = grid[i][j - level];
			float c = grid[i - level][j];
			float d = grid[i][j];
			float e = grid[i - level / 2][j - level / 2];

			grid[i - level][j - level / 2] = (a + c + e + grid[i - 3 *level / 2][j - level / 2]) / 4 + getRand() * range;
			grid[i - level / 2][j - level] = (a + b + e + grid[i - level / 2][j - 3 * level / 2]) / 4 + getRand() * range;
		}
	}
	diamondSquare(startX, startY, endX, endY, range / 2, level / 2);//recursive step
}

//finds the averaged normal of the point (x, grid[x][y], y)
vec3 getNormal(int x, int y){

	vec3 sum(0, 0, 0);//holds the sum of the normals
	float terms = 0;//holds the number of summands of sum

	bool quad1 = true;//top right quadrent
	bool quad2 = true;//top left quadrent
	bool quad3 = true;//bottom left quadrent
	bool quad4 = true;//bottom right quadrent

	//removes quadrents to calculate if they lie out of bounds
	if (x == 0){
		quad2 = false;
		quad3 = false;
	}
	if (y == 0){
		quad1 = false;
		quad2 = false;
	}
	if (x == size){
		quad1 = false;
		quad4 = false;
	}
	if (y == size){
		quad3 = false;
		quad4 = false;
	}

	vec3 centre = vec3(x, grid[x][y], y);//holds the main point

	//goes through each needed quadrent and adds the normals calculated by the cross product of centres adjacent verticies
	if (quad1){
		vec3 p0 = vec3(x, grid[x][y + 1], y + 1);
		vec3 p1 = vec3(x + 1, grid[x + 1][y + 1], y + 1);
		vec3 p2 = vec3(x + 1, grid[x + 1][y], y);

		sum += cross(p0 - centre, p1 - centre);
		sum += cross(p1 - centre, p2 - centre);

		terms += 2;
	}
	if (quad2){
		vec3 p0 = vec3(x, grid[x][y + 1], y + 1);
		vec3 p6 = vec3(x - 1, grid[x - 1][y], y);
		vec3 p7 = vec3(x - 1, grid[x - 1][y + 1], y + 1);

		sum += cross(p6 - centre, p7 - centre);
		sum += cross(p7 - centre, p0 - centre);

		terms += 2;
	}
	if (quad3){
		vec3 p4 = vec3(x, grid[x][y - 1], y - 1);
		vec3 p5 = vec3(x - 1, grid[x - 1][y - 1], y - 1);
		vec3 p6 = vec3(x - 1, grid[x - 1][y], y);

		sum += cross(p4 - centre, p5 - centre);
		sum += cross(p5 - centre, p6 - centre);

		terms += 2;
	}
	if (quad4){
		vec3 p2 = vec3(x + 1, grid[x + 1][y], y);
		vec3 p3 = vec3(x + 1, grid[x + 1][y - 1], y - 1);
		vec3 p4 = vec3(x, grid[x][y - 1], y - 1);

		sum += cross(p2 - centre, p3 - centre);
		sum += cross(p3 - centre, p4 - centre);

		terms += 2;
	}

	if (terms != 0) sum /= terms;//divides sum by terms to get the average if non-zero

	return normalize(sum);
}

//sets the vertex information of the calculated terrain
void genTerrain(){
	float dist = pow(0.5, 4);//used to shrink down the size of the terrain to get higher resolution
	int k = 0;
	for (int i = 0; i < size + 1; i++){
		for (int j = 0; j < size + 1; j++){
			//the four corners of the grid square.
			vec3 point0 = vec3(i, grid[i][j], j);
			vec3 point1 = vec3(i + 1, grid[i + 1][j], j);
			vec3 point2 = vec3(i, grid[i][j + 1], j + 1);
			vec3 point3 = vec3(i + 1, grid[i + 1][j + 1], j + 1);

			//the points normals
			vec3 norm0 = getNormal(i, j);
			vec3 norm1 = getNormal(i + 1, j);
			vec3 norm2 = getNormal(i, j + 1);
			vec3 norm3 = getNormal(i + 1, j + 1);
			
			//the two triangles to render the grid square
			//point0
			vPoint7[k] = point0[0] * dist;
			vPoint7[k + 1] = point0[1] * dist;
			vPoint7[k + 2] = point0[2] * dist;
			//colour0
			k += 3;
			vPoint7[k] = (float)i / (float)(size + 1);
			vPoint7[k + 1] = (float)j / (float)(size + 1);
			//normal0
			k += 2;
			vPoint7[k] = norm0[0];
			vPoint7[k + 1] = norm0[1];
			vPoint7[k + 2] = norm0[2];

			k += 3;
			//point2
			vPoint7[k] = point2[0] * dist;
			vPoint7[k + 1] = point2[1] * dist;
			vPoint7[k + 2] = point2[2] * dist;
			//colour2
			k += 3;
			vPoint7[k] = (float)(i + 1) / (float)(size + 1);
			vPoint7[k + 1] = (float)j / (float)(size + 1);
			//normal2
			k += 2;
			vPoint7[k] = norm2[0];
			vPoint7[k + 1] = norm2[1];
			vPoint7[k + 2] = norm2[2];

			k += 3;
			//point1
			vPoint7[k] = point1[0] * dist;
			vPoint7[k + 1] = point1[1] * dist;
			vPoint7[k + 2] = point1[2] * dist;
			//colour1
			k += 3;
			vPoint7[k] = (float)i / (float)(size + 1);
			vPoint7[k + 1] = (float)(j + 1) / (float)(size + 1);
			//normal1
			k += 2;
			vPoint7[k] = norm1[0];
			vPoint7[k + 1] = norm1[1];
			vPoint7[k + 2] = norm1[2];

			k += 3;
			//point3
			vPoint7[k] = point3[0] * dist;
			vPoint7[k + 1] = point3[1] * dist;
			vPoint7[k + 2] = point3[2] * dist;
			//colour3
			k += 3;
			vPoint7[k] = (float)(i + 1) / (float)(size + 1);
			vPoint7[k + 1] = (float)(j + 1) / (float)(size + 1);
			//normal3
			k += 2;
			vPoint7[k] = norm3[0];
			vPoint7[k + 1] = norm3[1];
			vPoint7[k + 2] = norm3[2];

			k += 3;
			//point1
			vPoint7[k] = point1[0] * dist;
			vPoint7[k + 1] = point1[1] * dist;
			vPoint7[k + 2] = point1[2] * dist;
			//colour1
			k += 3;
			vPoint7[k] = (float)i / (float)(size + 1);
			vPoint7[k + 1] = (float)(j + 1) / (float)(size + 1);
			//normal1
			k += 2;
			vPoint7[k] = norm1[0];
			vPoint7[k + 1] = norm1[1];
			vPoint7[k + 2] = norm1[2];

			k += 3;
			//point2
			vPoint7[k] = point2[0] * dist;
			vPoint7[k + 1] = point2[1] * dist;
			vPoint7[k + 2] = point2[2] * dist;
			//colour2
			k += 3;
			vPoint7[k] = (float)(i + 1) / (float)(size + 1);
			vPoint7[k + 1] = (float)j / (float)(size + 1);
			//normal2
			k += 2;
			vPoint7[k] = norm2[0];
			vPoint7[k + 1] = norm2[1];
			vPoint7[k + 2] = norm2[2];

			k += 3;
		}
	}
}

//goes through grid and sets every hight below the desired min to the min
void addPlaines(){
	for (int i = 0; i < size + 1; i++){
		for (int j = 0; j < size + 1; j++){
			float min = 0;//minimum depth
			if (grid[i][j] < min) grid[i][j] = min;
		}
	}
}

//Perlin Noise(works but not used at the moment)
const int PerlinLength = 256;

int Perm[PerlinLength] = { 151,160,137,91,90,15,131,13,201,95,96,53,164,233,7,225,140,36,103,30,69,142,8,99,37,240,21,10,23,
190,6,148,247,120,234,75,0,26,197,62,94,252,219,203,117,35,11,32,57,177,33,88,237,149,56,87,174,20,125,136,171,168,68,175,74,165,71,134,139,48,27,166,
77,146,158,231,83,111,229,122,60,211,133,230,220,105,92,41,55,46,245,40,244,102,143,54,65,25,63,161,1,216,80,73,209,76,132,187,208,89,18,169,200,196,
135,130,116,188,159,86,164,100,109,198,173,186,3,64,52,217,226,250,124,123,5,202,38,147,118,126,255,82,85,212,207,206,59,227,47,16,58,17,182,189,28,42,
223,183,170,213,119,248,152,2,44,154,163,70,221,153,101,155,167,43,172,9,129,22,39,253,19,98,108,110,79,113,224,232,178,185,112,104,218,246,97,228,
251,34,242,193,238,210,144,12,191,179,162241,81,51,145,235,249,14,239,107,49,192,214,31,181,199,106,157,184,84,204,176,115,121,50,45,127,4,150,254,
138,236,205,93,222,114,67,29,24,72,243,141,128,195,78,66,215,61,156,180};
float table[PerlinLength * 3];


void genTable(){
	srand(seed);
	for (int i = 0; i < PerlinLength; i++){
		float vx = 2 * getRand() - 1;
		float vy = 2 * getRand() - 1;
		float vz = 2 * getRand() - 1;

		while ((vx*vx + vy*vy + vz*vz) >= 1){
			vx = 2 * getRand() - 1;
			vy = 2 * getRand() - 1;
			vz = 2 * getRand() - 1;
		}
		vec3 vp = normalize(vec3(vx, vy, vz));
		table[3 * i] = vp[0];
		table[3 * i + 1] = vp[1];
		table[3 * i + 2] = vp[2];
	}
}

float omega(float t){
	t = abs(t);
	if (t < 1) return 2 * t*t*t - 3 * t*t + 1;//old
	//if (t < 1) return t * t * t * (t * (t * 6 - 15) + 10);//new
	else return 0;
}

int phi(int i){
	return Perm[i % PerlinLength];
}

vec3 gamma(int i, int j, int k){
	int index = phi(i + phi(j + phi(k)));
	vec3 temp = vec3(table[3 * index], table[3 * index + 1], table[3 * index + 2]);
	return temp;
}

float noise(float x, float y, float z){
	float sum = 0;
	for (int i = floorf(x); i <= floorf(x) + 1; i++){
		for (int j = floorf(y); j <= floorf(y) + 1; j++){
			for (int k = floorf(z); k <= floorf(z) + 1; k++){
				vec3 uvw = vec3(x - i, y - j, z - k);
				
				sum += omega(uvw[0]) * omega(uvw[1]) * omega(uvw[2]) * dot(gamma(i, j, k), uvw);
			}
		}
	}
	return sum;
}

void showPerlin(){
	genTable();
	for (int i = 0; i < PerlinLength; i++){
		printf("%f, ", noise(table[3 * i], table[3 * i + 1], table[3 * i + 2]));
		//printf("\n");
	}
}

void printTable(){
	genTable();
	for (int i = 0; i < 3 * PerlinLength; i++){
		printf("%f,", table[i]);
		//printf("\n");
	}
}

