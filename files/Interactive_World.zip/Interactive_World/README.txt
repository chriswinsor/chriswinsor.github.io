Name: Chris Winsor
Student Number: V00767709
Project: Interactive Cube Part 2

Description:
	Creates a scene of spheres and cubes above a terrain that can be rotated and scaled using the mouse.

Files Included: 
	main.cpp, shaders.h, diamondSquare.h

File Descriptions: more detail in the files

	main.cpp: runs the main code to create the interactive scene

	shaders.h: holds the vertex and fragment shaders used in main

	diamondSquare.h: implaments the diamond square algorithm. Also has an implamentation of Perlin noise but is not currently used.

Features:
	Renders a simple scene in perspective on the centre of the screen. Defult scene is a mini solar system with a sun, planet, and moon(moon rotating around the planet rotating around the sun)
	all hovering above a ramdomly generated terrain.
	
	Rotates verticaly and horizontaly with respect to the corrisponding mouse movement when the left mouse button is pressed

	Scales bigger or smaller with respect to the corrisponding mouse movement when the right mouse button is pressed

	The camera can also be set to follow a Bezier curve maintaining all camera control

	You can manualy move the camera's location using the 'wasd' keys

	Has cubes and procedurally generated spheres as provided primatives along with ramdomly generated terrain that can be uses to create the desired scene

	Has a colour mode and texture mode that can be swiched between using the USE_COLOUR variable at the top

	Colour mode renders all objects using the objects defined colour with the Phong light model

	Texture mode renders all objects using thier texture coordinates and given texture also using the Phong light model

	Texture mode also allows the use of normal maps to change the objects normals

	Texture mode also allows the use of background images

	Currently the sceen is rendered with a day/night cycle with corrisponding light levels and a golden colour at dawn/dusk

	The light colour can be modified by pressing '1' to add/remove the red component, '2' to add/remove the green component, and '3' to add/remove the blue component