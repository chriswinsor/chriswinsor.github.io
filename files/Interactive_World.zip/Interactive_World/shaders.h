//vertex shader for colour variation
const char * vshader = " \
	#version 330 core \n\
	in vec3 vPoint; \
	in vec3 vColour; \
	in vec3 vNormal; \
	out vec3 fragColour; \
	out vec3 fragNormal; \
	out vec3 fragPoint; \
	uniform mat4 Model; \
	uniform mat4 Mp; \
	uniform mat4 Mcam; \
	\
	void main() { \
		vec4 temp = Mp * Mcam * Model * vec4(vPoint, 1); \
		gl_Position = vec4(temp[0]/temp[3], temp[1]/temp[3], temp[2]/temp[3], 1); \
		fragColour = vColour; \
		fragNormal = vNormal; \
		fragPoint = vec3(Model * vec4(vPoint, 1)); \
	} \
	";//vec3(temp[0]/temp[3], temp[1]/temp[3], temp[2]/temp[3])
//fragment shader for colour variation. adds Phong light model for colour.
const char * fshader = " \
	#version 330 core \n\
	in vec3 fragColour; \
	in vec3 fragNormal; \
	in vec3 fragPoint; \
	out vec3 colour; \
	uniform mat4 Model; \
	uniform mat4 Mcam; \
	uniform vec3 lightSource; \
	uniform vec3 camera; \
	\
	void main() { \
		vec3 n = mat3(transpose(inverse(Model))) * fragNormal; \
		n = normalize(n); \
		vec3 l = lightSource - fragPoint; \
		l = normalize(l); \
		vec3 e = camera - fragPoint; \
		e = normalize(e); \
		vec3 h = e+l; \
		h = normalize(h); \
		\
		float difAngle = dot(n, l); \
		difAngle = clamp(difAngle, 0, 1); \
		float specAngle = dot(h, n); \
		specAngle = clamp(specAngle, 0, 1); \
		\
		vec3 lightColour = vec3(1, 1, 1); \
		vec3 difColour = fragColour * difAngle * lightColour; \
		vec3 specColour = pow(specAngle, 10) * lightColour; \
		vec3 ambColour = fragColour * vec3(0.1, 0.1, 0.1) * lightColour; \
		colour = difColour + specColour + ambColour; \
	} \
	";
//vertex shader for texture variation
const char * vshaderUV = " \
	#version 330 core \n\
	in vec3 vPoint; \
	in vec2 vUV; \
	in vec3 vNormal; \
	out vec2 fragUV; \
	out vec3 fragNormal; \
	out vec3 fragPoint; \
	uniform mat4 Model; \
	uniform mat4 Mp; \
	uniform mat4 Mcam; \
	uniform bool isBackground; \
	\
	void main() { \
		vec4 temp = Mp * Mcam * Model * vec4(vPoint, 1); \
		if (isBackground == false) gl_Position = vec4(temp[0]/temp[3], temp[1]/temp[3], temp[2]/temp[3], 1); \
		else gl_Position = vec4(vPoint, 1); \
		fragUV = vUV; \
		fragNormal = vNormal; \
		fragPoint = vec3(Model * vec4(vPoint, 1)); \
	} \
	";
//fragment shader for texture variation. adds Phong light model on the texture. uses normal maps if supplied
const char * fshaderUV = " \
	#version 330 core \n\
	in vec2 fragUV; \
	in vec3 fragNormal; \
	in vec3 fragPoint; \
	\
	out vec3 colour; \
	\
	uniform mat4 Model; \
	uniform mat4 Mcam; \
	uniform vec3 lightSource; \
	uniform vec3 lightColour; \
	uniform vec3 camera; \
	uniform sampler2D tex; \
	uniform sampler2D normTex; \
	uniform bool isBackground; \
	uniform bool useNormalMap; \
	uniform bool isTerrain; \
	uniform int red; \
	uniform int green; \
	uniform int blue; \
	\
	int seed = 160; \
	const int PerlinLength = 256; \
	\
	uniform int Perm[PerlinLength] = { 151,160,137,91,90,15,131,13,201,95,96,53,164,233,7,225,140,36,103,30,69,142,8,99,37,240,21,10,23, \
	190,6,148,247,120,234,75,0,26,197,62,94,252,219,203,117,35,11,32,57,177,33,88,237,149,56,87,174,20,125,136,171,168,68,175,74,165,71,134,139,48,27,166, \
	77,146,158,231,83,111,229,122,60,211,133,230,220,105,92,41,55,46,245,40,244,102,143,54,65,25,63,161,1,216,80,73,209,76,132,187,208,89,18,169,200,196, \
	135,130,116,188,159,86,164,100,109,198,173,186,3,64,52,217,226,250,124,123,5,202,38,147,118,126,255,82,85,212,207,206,59,227,47,16,58,17,182,189,28,42, \
	223,183,170,213,119,248,152,2,44,154,163,70,221,153,101,155,167,43,172,9,129,22,39,253,19,98,108,110,79,113,224,232,178,185,112,104,218,246,97,228, \
	251,34,242,193,238,210,144,12,191,179,162241,81,51,145,235,249,14,239,107,49,192,214,31,181,199,106,157,184,84,204,176,115,121,50,45,127,4,150,254, \
	138,236,205,93,222,114,67,29,24,72,243,141,128,195,78,66,215,61,156,180,1}; \
	\
	uniform sampler2D table; \
	\
	float omega(float t){ \
		t = abs(t); \
		if (t < 1) return 2 * t*t*t - 3 * t*t + 1; \
		else return 0; \
	} \
	\
	int phi(int i){ \
		return Perm[i % PerlinLength]; \
	} \
	\
	vec3 gamma(int i, int j, int k){ \
		int index = phi(i + phi(j + phi(k))); \
		vec3 temp = vec3(texture(table, vec2(index, 0)).r, texture(table, vec2(index, 0)).r, texture(table, vec2(index, 0)).r); \
		return temp; \
	} \
	\
	float noise(float x, float y, float z){ \
		float sum = 0; \
		for (int i = int(x); i <= int(x) + 1; i++){ \
			for (int j = int(y); j <= int(y) + 1; j++){ \
				for (int k = int(z); k <= int(z) + 1; k++){ \
					vec3 uvw = vec3(x - i, y - j, z - k); \
					sum += omega(uvw[0]) * omega(uvw[1]) * omega(uvw[2]) * dot(gamma(i, j, k), uvw); \
				} \
			} \
		} \
		return sum; \
	} \
	\
	void main() { \
		vec3 n; \
		if (useNormalMap == true && fragPoint[1] <= -1) n = mat3(transpose(inverse(Model))) * (texture(normTex, fragUV).rgb); \
		else n = mat3(transpose(inverse(Model))) * fragNormal; \
		n = normalize(n); \
		vec3 l = lightSource - fragPoint; \
		l = normalize(l); \
		vec3 e = camera - fragPoint; \
		e = normalize(e); \
		vec3 h = e+l; \
		h = normalize(h); \
		vec3 fragColour; \
		if (isTerrain == true){ \
			if (fragPoint[1] > 1.5) fragColour = vec3(1, 1, 1); \
			else if (fragPoint[1] > -0.8) fragColour = vec3(0.5, 0.5, 0.5); \
			else if (fragPoint[1] > -1) fragColour = vec3(0, 0.5, 0.1); \
			else fragColour = vec3(0, 0.1, 0.6); \
			\
			float t = (1 + sin(0.8 * fragPoint[0] + noise(fragPoint[0], fragPoint[1], fragPoint[2]) / 3)) / 2; \
			vec3 fragColour1 = t * vec3(0, 0.1, 0.6) + (1 - t) * vec3(0, 0.5, 0.1); \
		} \
		else fragColour = texture(tex, fragUV).rgb; \
		\
		float difAngle = dot(n, l); \
		difAngle = clamp(difAngle, 0, 1); \
		float specAngle = dot(h, n); \
		specAngle = clamp(specAngle, 0, 1); \
		\
		vec3 difColour = fragColour * difAngle * lightColour; \
		vec3 specColour = pow(specAngle, 100) * lightColour; \
		vec3 ambColour = fragColour * vec3(0.3, 0.3, 0.3) * lightColour; \
		if (isBackground == false) colour = difColour + 1*specColour + ambColour; \
		else colour = fragColour; \
	} \
		";/*
		float getRand(){
			\
				float f = rand() % 1000 - 500; \
				f /= 500; \
				return f; \
		} \
		void genTable(){
				\
					srand(seed); \
					for (int i = 0; i <= PerlinLength + 1; i++){
						\
							float vx = 2 * getRand() - 1; \
							float vy = 2 * getRand() - 1; \
							float vz = 2 * getRand() - 1; \
							\
							while ((vx*vx + vy*vy + vz*vz) >= 1){
								\
									vx = 2 * getRand() - 1; \
									vy = 2 * getRand() - 1; \
									vz = 2 * getRand() - 1; \
							} \
							table[i] = normalize(vec3(vx, vy, vz)); \
					} \
			} \
			\*/
