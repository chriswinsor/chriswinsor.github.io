#include "Canvas.h"
#include <math.h>
#include <stdlib.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include "shaders.h"
#include "diamondSquare.h"
#include "MatrixComp.h"

//constents
#define M_PI 3.141592653589//mathematical PI
const int lat = 20;//number of lines of latitude for sphere generation
const int lon = 20;//number of lines of longitude for sphere generation
const int sphereSize = lat * lon * 3 * 3 * 6;//the number of floats needed to store all the vertex info for the sphere

//true uses the objects colour, false uses the objects texture coordinates
bool USE_COLOUR = false;
bool USE_NORM_MAP = false;
bool part1 = false;

//the program uses glm as its vector/matrix library
using namespace glm;

//hight and width of the output screen 
unsigned int width = 512;
unsigned int height = 512;
Canvas canvas;

//variables used for screen interaction
float vppos_x = 0;//curser's x-coordinate
float lastvppos_x = 0;//curser's x-coordinate last used in the rotation calculation
float vppos_y = 0;//curser's y-coordinate
float lastvppos_y = 0;//curser's y-coordinate last used in the rotation calculation
bool leftButtonPressed = false;//true if the left mouse button is pressed
bool rightButtonPressed = false;//true if the right mouse button is pressed
float timer = 0;//increases by 0.1 with each new frame 
float zoom = 0;//zoom distance
float lastvppos_yD = 0;//curser's y-coordinate last used in the zoom calculation
float thetaV = 0;//vertical angle of camera
float thetaH = 0;//horizontal angle of camera
float x_move = 0;//translates the camera along the x-axis
float y_move = 0;//translates the camera along the y-axis

float speed = 1;//changes the speed at which everything moves. increased by pressing 'f' and decreased by pressing 'r'

int red = 1;//holds how much red is in the light colour. changed by pressing '1'
int green = 1;//holds how much green is in the light colour. changed by pressing '2'
int blue = 1;//holds how much blue is in the light colour. changed by pressing '3'

//importent points in world space
vec3 up(0, 1, 0);//general up direction
vec3 camera(0, 10, 0);//initial camera location
vec3 origin(0, 0, 0);//worlds centre
vec3 lightSource(10, 0, 0);//worlds light source location

//cubes vertex information with fixed colour
GLfloat vPoint4[] = {
	// coord      colour      normal
	//front
	-1, 1, 1,    0, 1, 0,    0, 0, 1,
	-1, -1, 1,    0, 1, 0,    0, 0, 1,
	1, -1, 1,    0, 1, 0,    0, 0, 1,
	1, -1, 1,    0, 1, 0,    0, 0, 1,
	1, 1, 1,    0, 1, 0,    0, 0, 1,
	-1, 1, 1,    0, 1, 0,    0, 0, 1,
	//top
	-1, 1, 1,    1, 0, 0,    0, 1, 0,
	1, 1, 1,    1, 0, 0,    0, 1, 0,
	1, 1, -1,    1, 0, 0,    0, 1, 0,
	1, 1, -1,    1, 0, 0,    0, 1, 0,
	-1, 1, -1,    1, 0, 0,    0, 1, 0,
	-1, 1, 1,    1, 0, 0,    0, 1, 0,
	//back
	-1, 1, -1,    0, 0, 1,    0, 0, -1,
	-1, -1, -1,    0, 0, 1,    0, 0, -1,
	1, -1, -1,    0, 0, 1,    0, 0, -1,
	1, -1, -1,    0, 0, 1,    0, 0, -1,
	1, 1, -1,    0, 0, 1,    0, 0, -1,
	-1, 1, -1,    0, 0, 1,    0, 0, -1,
	//bottom
	-1, -1, 1,    1, 1, 0,    0, -1, 0,
	1, -1, 1,    1, 1, 0,    0, -1, 0,
	1, -1, -1,    1, 1, 0,    0, -1, 0,
	1, -1, -1,    1, 1, 0,    0, -1, 0,
	-1, -1, -1,    1, 1, 0,    0, -1, 0,
	-1, -1, 1,    1, 1, 0,    0, -1, 0,
	//right
	1, 1, 1,    1, 0, 1,    1, 0, 0,
	1, -1, 1,    1, 0, 1,    1, 0, 0,
	1, -1, -1,    1, 0, 1,    1, 0, 0,
	1, -1, -1,    1, 0, 1,    1, 0, 0,
	1, 1, -1,    1, 0, 1,    1, 0, 0,
	1, 1, 1,    1, 0, 1,    1, 0, 0,
	//left
	-1, 1, 1,    0, 1, 1,    -1, 0, 0,
	-1, -1, 1,    0, 1, 1,    -1, 0, 0,
	-1, -1, -1,    0, 1, 1,    -1, 0, 0,
	-1, -1, -1,    0, 1, 1,    -1, 0, 0,
	-1, 1, -1,    0, 1, 1,    -1, 0, 0,
	-1, 1, 1,    0, 1, 1,    -1, 0, 0
};

//cubes vertex information with texture coordinates
GLfloat vPoint5[] = {
	// coord       UV          normal
	//front
	-1, 1, 1,    0, 1,    0, 0, 1,
	-1, -1, 1,    0, 0,    0, 0, 1,
	1, -1, 1,    1, 0,    0, 0, 1,
	1, -1, 1,    1, 0,    0, 0, 1,
	1, 1, 1,    1, 1,    0, 0, 1,
	-1, 1, 1,    0, 1,    0, 0, 1,
	//top
	-1, 1, 1,    0, 1,    0, 1, 0,
	1, 1, 1,    1, 1,    0, 1, 0,
	1, 1, -1,    1, 0,    0, 1, 0,
	1, 1, -1,    1, 0,    0, 1, 0,
	-1, 1, -1,    0, 0,    0, 1, 0,
	-1, 1, 1,    0, 1,    0, 1, 0,
	//back
	-1, 1, -1,    0, 1,    0, 0, -1,
	-1, -1, -1,    0, 0,    0, 0, -1,
	1, -1, -1,    1, 0,    0, 0, -1,
	1, -1, -1,    1, 0,    0, 0, -1,
	1, 1, -1,    1, 1,    0, 0, -1,
	-1, 1, -1,    0, 1,    0, 0, -1,
	//bottom
	-1, -1, 1,    0, 1,    0, -1, 0,
	1, -1, 1,    1, 1,    0, -1, 0,
	1, -1, -1,    1, 0,    0, -1, 0,
	1, -1, -1,    1, 0,    0, -1, 0,
	-1, -1, -1,    0, 0,    0, -1, 0,
	-1, -1, 1,    0, 1,    0, -1, 0,
	//right
	1, 1, 1,    1, 1,    1, 0, 0,
	1, -1, 1,    0, 1,    1, 0, 0,
	1, -1, -1,    0, 0,    1, 0, 0,
	1, -1, -1,    0, 0,    1, 0, 0,
	1, 1, -1,    1, 0,    1, 0, 0,
	1, 1, 1,    1, 1,    1, 0, 0,
	//left
	-1, 1, 1,    1, 1,    -1, 0, 0,
	-1, -1, 1,    0, 1,    -1, 0, 0,
	-1, -1, -1,    0, 0,    -1, 0, 0,
	-1, -1, -1,    0, 0,    -1, 0, 0,
	-1, 1, -1,    1, 0,    -1, 0, 0,
	-1, 1, 1,    1, 1,    -1, 0, 0
};

//spheres vertex information. initiated when desired sphereGen function is called
GLfloat vPoint6[sphereSize];

//fullscreen textured square that is used for a background image
GLfloat background[] = {
	// coord       UV      normal
	-1, 1, 0,    0, 1,    0, 0, 1,
	-1, -1, 0,    0, 0,    0, 0, 1,
	1, -1, 0,    1, 0,    0, 0, 1,
	1, -1, 0,    1, 0,    0, 0, 1,
	1, 1, 0,    1, 1,    0, 0, 1,
	-1, 1, 0,    0, 1,    0, 0, 1
};

//opengl location id's
GLuint VertexArrayID = 0;
GLuint programID = 0;
GLuint ModelBindingID = 0;
GLuint MpBindingID = 0;
GLuint McamBindingID = 0;
GLuint lightSourceBindingID = 0;
GLuint lightColourBindingID = 0;
GLuint cameraBindingID = 0;
GLuint useBackgroundBindingID = 0;
GLuint useNormalMapBindingID = 0;
GLuint isTerrainBindingID = 0;
GLuint tableBindingID = 0;
GLuint redBindingID = 0;
GLuint greenBindingID = 0;
GLuint blueBindingID = 0;

//various image textures to choose from
Texture backgroundtex = LoadPNGTexture("background.png");
Texture teximage1 = LoadPNGTexture("texture.png");
Texture teximage2 = LoadPNGTexture("texture2.png");
Texture teximage3 = LoadPNGTexture("texture3.png");
Texture sun = LoadPNGTexture("sun.png");
Texture planet = LoadPNGTexture("earth.png");
Texture moon = LoadPNGTexture("moon2.png");

//various normal map textures
Texture normteximage = LoadPNGTexture("normalMap.png");
Texture normteximage2 = LoadPNGTexture("normalMap2.png");
Texture normteximage3 = LoadPNGTexture("rock.png");

//generates the triangles to create a sphere with colour "colour"
void sphereGenColour(vec3 colour){
	int m = lon;
	int n = lat;
	int k = 0;
	//loops through each lat and lon using spherical coordinates to generate the two triangles needed to fill each block
	for (int i = 0; i < m; i++){
		for (int j = 0; j < n; j++){
			//point0
			vPoint6[k] = sin(M_PI * i / m) * cos(2 * M_PI * j / n);
			vPoint6[k + 1] = sin(M_PI * i / m) * sin(2 * M_PI * j / n);
			vPoint6[k + 2] = cos(M_PI * i / m);
			//colour0
			k += 3;
			vPoint6[k] = colour[0];
			vPoint6[k + 1] = colour[1];
			vPoint6[k + 2] = colour[2];
			//normal0
			k += 3;
			vPoint6[k] = sin(M_PI * i / m) * cos(2 * M_PI * j / n);
			vPoint6[k + 1] = sin(M_PI * i / m) * sin(2 * M_PI * j / n);
			vPoint6[k + 2] = cos(M_PI * i / m);

			//point2
			k += 3;
			vPoint6[k] = sin(M_PI * (i + 1) / m) * cos(2 * M_PI * j / n);
			vPoint6[k + 1] = sin(M_PI * (i + 1) / m) * sin(2 * M_PI * j / n);
			vPoint6[k + 2] = cos(M_PI * (i + 1) / m);
			//colour2
			k += 3;
			vPoint6[k] = colour[0];
			vPoint6[k + 1] = colour[1];
			vPoint6[k + 2] = colour[2];
			//normal2
			k += 3;
			vPoint6[k] = sin(M_PI * (i + 1) / m) * cos(2 * M_PI * j / n);
			vPoint6[k + 1] = sin(M_PI * (i + 1) / m) * sin(2 * M_PI * j / n);
			vPoint6[k + 2] = cos(M_PI * (i + 1) / m);

			//point1
			k += 3;
			vPoint6[k] = sin(M_PI * i / m) * cos(2 * M_PI * (j + 1) / n);
			vPoint6[k + 1] = sin(M_PI * i / m) * sin(2 * M_PI * (j + 1) / n);
			vPoint6[k + 2] = cos(M_PI * i / m);
			//colour1
			k += 3;
			vPoint6[k] = colour[0];
			vPoint6[k + 1] = colour[1];
			vPoint6[k + 2] = colour[2];
			//normal1
			k += 3;
			vPoint6[k] = sin(M_PI * i / m) * cos(2 * M_PI * (j + 1) / n);
			vPoint6[k + 1] = sin(M_PI * i / m) * sin(2 * M_PI * (j + 1) / n);
			vPoint6[k + 2] = cos(M_PI * i / m);

			//point3
			k += 3;
			vPoint6[k] = sin(M_PI * (i + 1) / m) * cos(2 * M_PI * (j + 1) / n);
			vPoint6[k + 1] = sin(M_PI * (i + 1) / m) * sin(2 * M_PI * (j + 1) / n);
			vPoint6[k + 2] = cos(M_PI * (i + 1) / m);
			//colour3
			k += 3;
			vPoint6[k] = colour[0];
			vPoint6[k + 1] = colour[1];
			vPoint6[k + 2] = colour[2];
			//normal3
			k += 3;
			vPoint6[k] = sin(M_PI * (i + 1) / m) * cos(2 * M_PI * (j + 1) / n);
			vPoint6[k + 1] = sin(M_PI * (i + 1) / m) * sin(2 * M_PI * (j + 1) / n);
			vPoint6[k + 2] = cos(M_PI * (i + 1) / m);

			//point1
			k += 3;
			vPoint6[k] = sin(M_PI * i / m) * cos(2 * M_PI * (j + 1) / n);
			vPoint6[k + 1] = sin(M_PI * i / m) * sin(2 * M_PI * (j + 1) / n);
			vPoint6[k + 2] = cos(M_PI * i / m);
			//colour1
			k += 3;
			vPoint6[k] = colour[0];
			vPoint6[k + 1] = colour[1];
			vPoint6[k + 2] = colour[2];
			//normal1
			k += 3;
			vPoint6[k] = sin(M_PI * i / m) * cos(2 * M_PI * (j + 1) / n);
			vPoint6[k + 1] = sin(M_PI * i / m) * sin(2 * M_PI * (j + 1) / n);
			vPoint6[k + 2] = cos(M_PI * i / m);

			//point2
			k += 3;
			vPoint6[k] = sin(M_PI * (i + 1) / m) * cos(2 * M_PI * j / n);
			vPoint6[k + 1] = sin(M_PI * (i + 1) / m) * sin(2 * M_PI * j / n);
			vPoint6[k + 2] = cos(M_PI * (i + 1) / m);
			//colour2
			k += 3;
			vPoint6[k] = colour[0];
			vPoint6[k + 1] = colour[1];
			vPoint6[k + 2] = colour[2];
			//normal2
			k += 3;
			vPoint6[k] = sin(M_PI * (i + 1) / m) * cos(2 * M_PI * j / n);
			vPoint6[k + 1] = sin(M_PI * (i + 1) / m) * sin(2 * M_PI * j / n);
			vPoint6[k + 2] = cos(M_PI * (i + 1) / m);

			k += 3;
		}
	}
}

//generates the triangles to create a sphere with a texture filling each block
void sphereGenUVTiled(){
	int m = lon;
	int n = lat;
	int k = 0;
	//loops through each lat and lon using spherical coordinates to generate the two triangles needed to fill each block
	for (int i = 0; i < m; i++){
		for (int j = 0; j < n; j++){
			//point0
			vPoint6[k] = sin(M_PI * i / m) * cos(2 * M_PI * j / n);
			vPoint6[k + 1] = sin(M_PI * i / m) * sin(2 * M_PI * j / n);
			vPoint6[k + 2] = cos(M_PI * i / m);
			//colour0
			k += 3;
			vPoint6[k] = 0;
			vPoint6[k + 1] = 1;
			//normal0
			k += 2;
			vPoint6[k] = sin(M_PI * i / m) * cos(2 * M_PI * j / n);
			vPoint6[k + 1] = sin(M_PI * i / m) * sin(2 * M_PI * j / n);
			vPoint6[k + 2] = cos(M_PI * i / m);

			//point2
			k += 3;
			vPoint6[k] = sin(M_PI * (i + 1) / m) * cos(2 * M_PI * j / n);
			vPoint6[k + 1] = sin(M_PI * (i + 1) / m) * sin(2 * M_PI * j / n);
			vPoint6[k + 2] = cos(M_PI * (i + 1) / m);
			//colour2
			k += 3;
			vPoint6[k] = 0;
			vPoint6[k + 1] = 0;
			//normal2
			k += 2;
			vPoint6[k] = sin(M_PI * (i + 1) / m) * cos(2 * M_PI * j / n);
			vPoint6[k + 1] = sin(M_PI * (i + 1) / m) * sin(2 * M_PI * j / n);
			vPoint6[k + 2] = cos(M_PI * (i + 1) / m);

			//point1
			k += 3;
			vPoint6[k] = sin(M_PI * i / m) * cos(2 * M_PI * (j + 1) / n);
			vPoint6[k + 1] = sin(M_PI * i / m) * sin(2 * M_PI * (j + 1) / n);
			vPoint6[k + 2] = cos(M_PI * i / m);
			//colour1
			k += 3;
			vPoint6[k] = 1;
			vPoint6[k + 1] = 1;
			//normal1
			k += 2;
			vPoint6[k] = sin(M_PI * i / m) * cos(2 * M_PI * (j + 1) / n);
			vPoint6[k + 1] = sin(M_PI * i / m) * sin(2 * M_PI * (j + 1) / n);
			vPoint6[k + 2] = cos(M_PI * i / m);

			//point3
			k += 3;
			vPoint6[k] = sin(M_PI * (i + 1) / m) * cos(2 * M_PI * (j + 1) / n);
			vPoint6[k + 1] = sin(M_PI * (i + 1) / m) * sin(2 * M_PI * (j + 1) / n);
			vPoint6[k + 2] = cos(M_PI * (i + 1) / m);
			//colour3
			k += 3;
			vPoint6[k] = 1;
			vPoint6[k + 1] = 0;
			//normal3
			k += 2;
			vPoint6[k] = sin(M_PI * (i + 1) / m) * cos(2 * M_PI * (j + 1) / n);
			vPoint6[k + 1] = sin(M_PI * (i + 1) / m) * sin(2 * M_PI * (j + 1) / n);
			vPoint6[k + 2] = cos(M_PI * (i + 1) / m);

			//point1
			k += 3;
			vPoint6[k] = sin(M_PI * i / m) * cos(2 * M_PI * (j + 1) / n);
			vPoint6[k + 1] = sin(M_PI * i / m) * sin(2 * M_PI * (j + 1) / n);
			vPoint6[k + 2] = cos(M_PI * i / m);
			//colour1
			k += 3;
			vPoint6[k] = 1;
			vPoint6[k + 1] = 1;
			//normal1
			k += 2;
			vPoint6[k] = sin(M_PI * i / m) * cos(2 * M_PI * (j + 1) / n);
			vPoint6[k + 1] = sin(M_PI * i / m) * sin(2 * M_PI * (j + 1) / n);
			vPoint6[k + 2] = cos(M_PI * i / m);

			//point2
			k += 3;
			vPoint6[k] = sin(M_PI * (i + 1) / m) * cos(2 * M_PI * j / n);
			vPoint6[k + 1] = sin(M_PI * (i + 1) / m) * sin(2 * M_PI * j / n);
			vPoint6[k + 2] = cos(M_PI * (i + 1) / m);
			//colour2
			k += 3;
			vPoint6[k] = 0;
			vPoint6[k + 1] = 0;
			//normal2
			k += 2;
			vPoint6[k] = sin(M_PI * (i + 1) / m) * cos(2 * M_PI * j / n);
			vPoint6[k + 1] = sin(M_PI * (i + 1) / m) * sin(2 * M_PI * j / n);
			vPoint6[k + 2] = cos(M_PI * (i + 1) / m);

			k += 3;
		}
	}
}

//generates the triangles to create a sphere with a texture streched across the whole face
void sphereGenUV(){
	int m = lon;
	int n = lat;
	int k = 0;
	//loops through each lat and lon using spherical coordinates to generate the two triangles needed to fill each block
	for (int i = 0; i < m; i++){
		for (int j = 0; j < n; j++){
			//point0
			vPoint6[k] = sin(M_PI * i / m) * cos(2 * M_PI * j / n);
			vPoint6[k + 1] = sin(M_PI * i / m) * sin(2 * M_PI * j / n);
			vPoint6[k + 2] = cos(M_PI * i / m);
			//UV0
			k += 3;
			float phi = atan2f(vPoint6[k - 2], vPoint6[k - 3]);
			float theta = acos(vPoint6[k - 1]);
			if (phi < 0) phi += 2 * M_PI;
			vPoint6[k] = phi / (2 * M_PI);
			vPoint6[k + 1] = (M_PI - theta) / (M_PI);
			//normal0
			k += 2;
			vPoint6[k] = sin(M_PI * i / m) * cos(2 * M_PI * j / n);
			vPoint6[k + 1] = sin(M_PI * i / m) * sin(2 * M_PI * j / n);
			vPoint6[k + 2] = cos(M_PI * i / m);

			//point2
			k += 3;
			vPoint6[k] = sin(M_PI * (i + 1) / m) * cos(2 * M_PI * j / n);
			vPoint6[k + 1] = sin(M_PI * (i + 1) / m) * sin(2 * M_PI * j / n);
			vPoint6[k + 2] = cos(M_PI * (i + 1) / m);
			//UV2
			k += 3;
			phi = atan2f(vPoint6[k - 2], vPoint6[k - 3]);
			theta = acos(vPoint6[k - 1]);
			if (phi < 0) phi += 2 * M_PI;
			vPoint6[k] = phi / (2 * M_PI);
			vPoint6[k + 1] = (M_PI - theta) / (M_PI);
			//normal2
			k += 2;
			vPoint6[k] = sin(M_PI * (i + 1) / m) * cos(2 * M_PI * j / n);
			vPoint6[k + 1] = sin(M_PI * (i + 1) / m) * sin(2 * M_PI * j / n);
			vPoint6[k + 2] = cos(M_PI * (i + 1) / m);

			//point1
			k += 3;
			vPoint6[k] = sin(M_PI * i / m) * cos(2 * M_PI * (j + 1) / n);
			vPoint6[k + 1] = sin(M_PI * i / m) * sin(2 * M_PI * (j + 1) / n);
			vPoint6[k + 2] = cos(M_PI * i / m);
			//UV1
			k += 3;
			phi = atan2f(vPoint6[k - 2], vPoint6[k - 3]);
			theta = acos(vPoint6[k - 1]);
			if (phi < 0) phi += 2 * M_PI;
			vPoint6[k] = phi / (2 * M_PI);
			vPoint6[k + 1] = (M_PI - theta) / (M_PI);
			//normal1
			k += 2;
			vPoint6[k] = sin(M_PI * i / m) * cos(2 * M_PI * (j + 1) / n);
			vPoint6[k + 1] = sin(M_PI * i / m) * sin(2 * M_PI * (j + 1) / n);
			vPoint6[k + 2] = cos(M_PI * i / m);

			//point3
			k += 3;
			vPoint6[k] = sin(M_PI * (i + 1) / m) * cos(2 * M_PI * (j + 1) / n);
			vPoint6[k + 1] = sin(M_PI * (i + 1) / m) * sin(2 * M_PI * (j + 1) / n);
			vPoint6[k + 2] = cos(M_PI * (i + 1) / m);
			//UV3
			k += 3;
			phi = atan2f(vPoint6[k - 2], vPoint6[k - 3]);
			theta = acos(vPoint6[k - 1]);
			if (phi < 0) phi += 2 * M_PI;
			vPoint6[k] = phi / (2 * M_PI);
			vPoint6[k + 1] = (M_PI - theta) / (M_PI);
			//normal3
			k += 2;
			vPoint6[k] = sin(M_PI * (i + 1) / m) * cos(2 * M_PI * (j + 1) / n);
			vPoint6[k + 1] = sin(M_PI * (i + 1) / m) * sin(2 * M_PI * (j + 1) / n);
			vPoint6[k + 2] = cos(M_PI * (i + 1) / m);

			//point1
			k += 3;
			vPoint6[k] = sin(M_PI * i / m) * cos(2 * M_PI * (j + 1) / n);
			vPoint6[k + 1] = sin(M_PI * i / m) * sin(2 * M_PI * (j + 1) / n);
			vPoint6[k + 2] = cos(M_PI * i / m);
			//UV1
			k += 3;
			phi = atan2f(vPoint6[k - 2], vPoint6[k - 3]);
			theta = acos(vPoint6[k - 1]);
			if (phi < 0) phi += 2 * M_PI;
			vPoint6[k] = phi / (2 * M_PI);
			vPoint6[k + 1] = (M_PI - theta) / (M_PI);
			//normal1
			k += 2;
			vPoint6[k] = sin(M_PI * i / m) * cos(2 * M_PI * (j + 1) / n);
			vPoint6[k + 1] = sin(M_PI * i / m) * sin(2 * M_PI * (j + 1) / n);
			vPoint6[k + 2] = cos(M_PI * i / m);

			//point2
			k += 3;
			vPoint6[k] = sin(M_PI * (i + 1) / m) * cos(2 * M_PI * j / n);
			vPoint6[k + 1] = sin(M_PI * (i + 1) / m) * sin(2 * M_PI * j / n);
			vPoint6[k + 2] = cos(M_PI * (i + 1) / m);
			//UV2
			k += 3;
			phi = atan2f(vPoint6[k - 2], vPoint6[k - 3]);
			theta = acos(vPoint6[k - 1]);
			if (phi < 0) phi += 2 * M_PI;
			vPoint6[k] = phi / (2 * M_PI);
			vPoint6[k + 1] = (M_PI - theta) / (M_PI);
			//normal2
			k += 2;
			vPoint6[k] = sin(M_PI * (i + 1) / m) * cos(2 * M_PI * j / n);
			vPoint6[k + 1] = sin(M_PI * (i + 1) / m) * sin(2 * M_PI * j / n);
			vPoint6[k + 2] = cos(M_PI * (i + 1) / m);

			k += 3;
		}
	}
}

//sets the image texture(GL_TEXTURE0) to "image"
void useTexture(Texture image){
	glActiveTexture(GL_TEXTURE0);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, image.width,
		image.height, 0, GL_RGBA, GL_UNSIGNED_BYTE,
		image.dataptr);
}

//sets both the image texture(GL_TEXTURE0) to "image" and the normal map texture(GL_TEXTURE1) to "normal"
void useTexture(Texture image, Texture normal){
	glActiveTexture(GL_TEXTURE0);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, image.width,
		image.height, 0, GL_RGBA, GL_UNSIGNED_BYTE,
		image.dataptr);

	glActiveTexture(GL_TEXTURE1);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, normal.width,
		normal.height, 0, GL_RGBA, GL_UNSIGNED_BYTE,
		normal.dataptr);
}

//initilizes all the opengl objects and variables
void InitializeGL()
{
	//initilizes vPoint6 with the desired type of sphere
	if (USE_COLOUR) sphereGenColour(vec3(0, 1, 1));
	else sphereGenUV();
	
	//generates the vertex array object
	glGenVertexArrays(1, &VertexArrayID);
	glBindVertexArray(VertexArrayID);

	//compiles the correct shaders for basic colour or textures
	if (USE_COLOUR) programID = compile_shaders(vshader, fshader);
	else programID = compile_shaders(vshaderUV, fshaderUV);
	glUseProgram(programID);
	
	//pointer to where the verticies are located
	GLuint vPoint_id = glGetAttribLocation(programID, "vPoint");
	glEnableVertexAttribArray(vPoint_id);
	if (USE_COLOUR) glVertexAttribPointer(vPoint_id, 3, GL_FLOAT, false, 9 * sizeof(GLfloat), 0);
	else glVertexAttribPointer(vPoint_id, 3, GL_FLOAT, false, 8 * sizeof(GLfloat), 0);

	//pointer to where the vertex colours/UV coordinates are located
	if (USE_COLOUR){
		GLuint vColour_id = glGetAttribLocation(programID, "vColour");
		glEnableVertexAttribArray(vColour_id);
		glVertexAttribPointer(vColour_id, 3, GL_FLOAT, false, 9 * sizeof(GLfloat), (const GLvoid*)(3 * sizeof(GLfloat)));
	}
	else{
		GLuint vUV_id = glGetAttribLocation(programID, "vUV");
		glEnableVertexAttribArray(vUV_id);
		glVertexAttribPointer(vUV_id, 2, GL_FLOAT, false, 8 * sizeof(GLfloat), (const GLvoid*)(3 * sizeof(GLfloat)));
	}

	//pointer to where the vertex normals are located
	GLuint vNormal_id = glGetAttribLocation(programID, "vNormal");
	glEnableVertexAttribArray(vNormal_id);
	if (USE_COLOUR) glVertexAttribPointer(vNormal_id, 3, GL_FLOAT, false, 9 * sizeof(GLfloat), (const GLvoid*)(6 * sizeof(GLfloat)));
	else glVertexAttribPointer(vNormal_id, 3, GL_FLOAT, false, 8 * sizeof(GLfloat), (const GLvoid*)(5 * sizeof(GLfloat)));

	//locations of all the shader uniforms
	ModelBindingID = glGetUniformLocation(programID, "Model");
	MpBindingID = glGetUniformLocation(programID, "Mp");
	McamBindingID = glGetUniformLocation(programID, "Mcam");
	lightSourceBindingID = glGetUniformLocation(programID, "lightSource");
	lightColourBindingID = glGetUniformLocation(programID, "lightColour");
	cameraBindingID = glGetUniformLocation(programID, "camera");
	useBackgroundBindingID = glGetUniformLocation(programID, "isBackground");
	useNormalMapBindingID = glGetUniformLocation(programID, "useNormalMap");
	isTerrainBindingID = glGetUniformLocation(programID, "isTerrain");
	redBindingID = glGetUniformLocation(programID, "red");
	greenBindingID = glGetUniformLocation(programID, "green");
	blueBindingID = glGetUniformLocation(programID, "blue");

	genTable();
	tableBindingID = glGetUniformLocation(programID, "table");
	//glUniform1fv(tableBindingID, 12, table);

	//initiates the image texture(GL_TEXTURE0) and normal map(GL_TEXTURE1)
	if (!USE_COLOUR){
		//creates the image texture object
		GLuint texobject;
		glGenTextures(1, &texobject);
		glBindTexture(GL_TEXTURE_2D, texobject);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, teximage1.width,
			teximage1.height, 0, GL_RGBA, GL_UNSIGNED_BYTE,
			teximage1.dataptr);

		//creates the normal map object
		GLuint normtexobject;
		glGenTextures(1, &normtexobject);
		glBindTexture(GL_TEXTURE_2D, normtexobject);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, normteximage.width,
			normteximage.height, 0, GL_RGBA, GL_UNSIGNED_BYTE,
			normteximage.dataptr);

		//creates the normal map object
		GLuint tableArray;
		glGenTextures(1, &tableArray);
		glBindTexture(GL_TEXTURE_2D, tableArray);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, 3,
			PerlinLength, 0, GL_DEPTH_COMPONENT, GL_FLOAT,
			table);

		//activates the two textures and binds them
		GLuint tex_id = glGetUniformLocation(programID, "tex");
		glUniform1i(tex_id, 0);
		
		tex_id = glGetUniformLocation(programID, "normTex");
		glUniform1i(tex_id, 1);

		glUniform1i(tableBindingID, 2);
		
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texobject);

		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, normtexobject);

		glActiveTexture(GL_TEXTURE2);
		glBindTexture(GL_TEXTURE_2D, tableArray);
	}
}

//returns the point at 't' given the four control points
vec3 getBezierPoint(vec3 p0, vec3 p1, vec3 p2, vec3 p3, float t){
	if (t > 1) t = 1;
	if (t < 0) t = 0;
	float b0 = 1 - 3 * t + 3 * t * t - t * t * t;
	float b1 = 3 * t - 6 * t * t + 3 * t * t * t;
	float b2 = 3 * t * t - 3 * t * t * t;
	float b3 = t * t * t;
	return b0 * p0 + b1 * p1 + b2 * p2 + b3 * p3;
}

//used for part 1 to draw a Bezier Curve using lines.
void DrawBezierCurve(vec3 controlPoints[], int length){
	int start = 0;
	int depth = 100;
	while (start < length - 3){
		for (int i = 0; i < depth; i++){
			vec3 point = getBezierPoint(controlPoints[start], controlPoints[start + 1], controlPoints[start + 2], controlPoints[start + 3], (float)i / depth);
			vec3 point2 = getBezierPoint(controlPoints[start], controlPoints[start + 1], controlPoints[start + 2], controlPoints[start + 3], (float)(i + 1) / depth);

			canvas.AddLine(point[0], point[1], point2[0], point2[1]);
		}
		start += 3;
	}
}

//draws a wireframe cube as needed in part 1
void DrawCubePart1(mat4 m){
	vec4 a(-.5, .5, .5, 1);//front square verticies
	vec4 b(.5, .5, .5, 1);
	vec4 c(.5, -.5, .5, 1);
	vec4 d(-.5, -.5, .5, 1);

	vec4 aa(-.5, .5, -.5, 1);//back square verticies
	vec4 bb(.5, .5, -.5, 1);
	vec4 cc(.5, -.5, -.5, 1);
	vec4 dd(-.5, -.5, -.5, 1);

	//progects the points in prospective
	a = m*a;
	b = m*b;
	c = m*c;
	d = m*d;
	aa = m*aa;
	bb = m*bb;
	cc = m*cc;
	dd = m*dd;

	//dehomogenizes the points
	a /= a[3];
	b /= b[3];
	c /= c[3];
	d /= d[3];
	aa /= aa[3];
	bb /= bb[3];
	cc /= cc[3];
	dd /= dd[3];


	//outputs front lines
	canvas.AddLine(a[0], a[1], b[0], b[1]);
	canvas.AddLine(b[0], b[1], c[0], c[1]);
	canvas.AddLine(c[0], c[1], d[0], d[1]);
	canvas.AddLine(d[0], d[1], a[0], a[1]);

	//outputs back lines
	canvas.AddLine(aa[0], aa[1], bb[0], bb[1]);
	canvas.AddLine(bb[0], bb[1], cc[0], cc[1]);
	canvas.AddLine(cc[0], cc[1], dd[0], dd[1]);
	canvas.AddLine(dd[0], dd[1], aa[0], aa[1]);

	//outputs sides lines
	canvas.AddLine(a[0], a[1], aa[0], aa[1]);
	canvas.AddLine(b[0], b[1], bb[0], bb[1]);
	canvas.AddLine(c[0], c[1], cc[0], cc[1]);
	canvas.AddLine(d[0], d[1], dd[0], dd[1]);
}

//draws a cube in the location defined by "model"
void drawCube(mat4 model)
{
	//sets the vertex information to one of the cubes
	if (USE_COLOUR) glBufferData(GL_ARRAY_BUFFER, sizeof(vPoint4), vPoint4, GL_STATIC_DRAW);
	else glBufferData(GL_ARRAY_BUFFER, sizeof(vPoint5), vPoint5, GL_STATIC_DRAW);

	glUniformMatrix4fv(ModelBindingID, 1, GL_FALSE, &model[0][0]);//sets the model matrix to "model"

	glDrawArrays(GL_TRIANGLES, 0, 36);//draws the cube
}

//draws a sphere in the location defined by "model"
void drawSphere(mat4 model)
{
	//sets the vertex information to the sphere
	glBufferData(GL_ARRAY_BUFFER, sizeof(vPoint6), vPoint6, GL_STATIC_DRAW);

	glUniformMatrix4fv(ModelBindingID, 1, GL_FALSE, &model[0][0]);//sets the model matrix to "model"

	glDrawArrays(GL_TRIANGLES, 0, sphereSize);//draws the sphere
}

//draws the terrain in the location defined by "model"
void drawTerrain(mat4 model)
{
	//sets the vertex information to the sphere
	glBufferData(GL_ARRAY_BUFFER, sizeof(vPoint7), vPoint7, GL_STATIC_DRAW);

	glUniformMatrix4fv(ModelBindingID, 1, GL_FALSE, &model[0][0]);//sets the model matrix to "model"

	glDrawArrays(GL_TRIANGLES, 0, (size + 1) * (size + 1) * 9 * 6 * 3);//draws the sphere
}

//draws the background image
void drawBackground(){
	mat4 identity = mat4();//basic identity matrix

	glBufferData(GL_ARRAY_BUFFER, sizeof(background), background, GL_STATIC_DRAW);//sets the vertex information to the background

	useTexture(backgroundtex);//sets the image texture to the background image
	glUniformMatrix4fv(ModelBindingID, 1, GL_FALSE, &identity[0][0]);//sets the model matrix to the identity matrix so it stays in place
	
	//turns on useBackground to draw the background and turns it off when done
	glUniform1i(useBackgroundBindingID, true);
	glDrawArrays(GL_TRIANGLES, 0, 6);
	glUniform1i(useBackgroundBindingID, false);
}

//gets the current mouse location and stores it
void MouseMove(double x, double y)
{
   vppos_x = (float)(x) / (width * 0.5) - 1;
   vppos_y = 1 - (float)(y) / (width * 0.5);
}

//sets the desired variables when the mouse buttons are pressed
void MouseButton(MouseButtons mouseButton, bool press)
{
    if (mouseButton == LeftButton)
    {
		if (press == true){
			leftButtonPressed = true;
			lastvppos_x = vppos_x;
			lastvppos_y = vppos_y;
		}
		else leftButtonPressed = false;
    }
	if (mouseButton == RightButton)
	{
		if (press == true){
			rightButtonPressed = true;
			lastvppos_yD = vppos_y;
		}
		else rightButtonPressed = false;
	}
}

//sets the desired variables when a keyboard button is pressed(no button functionality added yet)
void KeyPress(char keychar)
{
	//printf("%i is %c, ", keychar, keychar);//used to find the int value of a char
	if (keychar == 32)
	{
		if (USE_NORM_MAP == true)
		{
			USE_NORM_MAP = false;
		}
		else USE_NORM_MAP = true;
	}
	if (keychar == 87) y_move -= 1;//w
	if (keychar == 65) x_move += 1;//a
	if (keychar == 83) y_move += 1;//s
	if (keychar == 68) x_move -= 1;//d

	if (keychar == 82) speed -= 0.2;//r
	if (keychar == 70) speed += 0.2;//f

	if (keychar == 49) red = (red + 1) % 2;//1
	if (keychar == 50) green = (green + 1) % 2;//2
	if (keychar == 51) blue = (blue + 1) % 2;//3
}


//draws the current calculated frame of the scene. Current scene is a mini solar system with a sun, planet, and moon hovering over a terrain
void OnPaint()
{
	//adjusts the rotation angles depending on the mouse movement when the left mouse button is pressed
	if (leftButtonPressed == true)
	{
		//the distances the mouse has moved since the last calculation
		float deltaDx = vppos_x - lastvppos_x;
		float deltaDy = vppos_y - lastvppos_y;
		
		//adjusts the angles based on the distance moved such that one screen length of movement rotates by 180 degrees
		thetaH += -0.5 * M_PI * deltaDx;
		thetaV += -0.5 * M_PI * deltaDy;

		//resets last position calculated
		lastvppos_x = vppos_x;
		lastvppos_y = vppos_y;
	}

	//adjusts the zoom ratio depending on the mouse movement when the right mouse button is pressed
	if (rightButtonPressed == true)
	{
		float deltaDy = vppos_y - lastvppos_yD;//the distances the mouse has moved since the last calculation
		zoom += 5*deltaDy;//adjusts the zoom distance bases on the distance moved
		lastvppos_yD = vppos_y;//resets last position calculated
	}

	//camera movement along a Bezier Curve
	vec3 controlPoints[] = { vec3(-10, 0, camera[2]), vec3(-0, 10, camera[2]), vec3(-0, 0, camera[2]), vec3(5, 0, camera[2]), vec3(5, 0, camera[2]), vec3(5, -10, camera[2]), vec3(0, 0, camera[2]), vec3(5, 0, camera[2]), vec3(5, 0, 5 + camera[2]), vec3(10, 0, 12), vec3(10, 0, -10), vec3(-10, 0, -10), vec3(-10, 0, 10), vec3(10, 0, 10), vec3(5, 0, 8), vec3(0, 0, camera[2]) };
	int cplength = 7;//number of control points to be used
	int depth = 100 - speed;
	int i = (int)(timer * 10) % depth;//loops through 0 to depth to split the curve into depth segments
	vec3 point;//current point along the curve
	int start = floor((timer * 10) / depth) * 3;//holds the current starting control point
	if (start < cplength - 3) point = getBezierPoint(controlPoints[start], controlPoints[start + 1], controlPoints[start + 2], controlPoints[start + 3], (float)i / depth);//finds the current point on the curve
	else {
		start = cplength;
		point = controlPoints[start - 1];//sets point to the last control point if it is finished traversing the curve
	}

	//rotates the lightsoure around the sceen and sets the light colour depending on its height(bright "day", dark "night, gold "dusk/dawn"
	vec3 lightPos = vec3(rotate(mat4(), 0.5f*timer, vec3(0, 0, 1)) * vec4(lightSource, 1));
	vec3 lightColour = vec3(1, 1, 0.5 + 0.5*abs(lightPos[1] / 10)) * ((2 + (lightPos[1] / 10))/2);
	lightColour = vec3(red * lightColour[0], green * lightColour[1], blue * lightColour[2]);

	mat4 movement = mat4();
	movement = translate(movement, vec3(x_move, y_move, zoom));
	movement = rotate(movement, thetaV, vec3(1, 0, 0));
	movement = rotate(movement, -thetaH, vec3(0, 1, 0));

	vec4 temp1 = movement * vec4(camera, 1);
	vec3 temp = vec3(temp1[0] / temp1[3], temp1[1] / temp1[3], temp1[2] / temp1[3]);
	vec3 camera1 = vec3(zoom * camera[0] * sin(M_PI * thetaV) * cos(2 * M_PI * thetaH),
		zoom * camera[1] * sin(M_PI * thetaV) * sin(2 * M_PI * thetaH), zoom * camera[2] * cos(M_PI * thetaV));

	//calculates the perspective and camera transformation matricies. (move the translate and rotations from the model matrix to the camera matrix so the lightsource moves with the scene)
	mat4 mp = perspective(radians(50.0f), 1.0f, 0.1f, 100.0f);
	//mp = morthComp(vec3(-1, 1, -1), vec3(1, -1, -10));// *mpComp(-1, -10);;
	mat4 mcam = mat4();
	//mcam = lookAt(camera, origin, up);
	//mcam = translate(mcam, -camera);
	//mcam = translate(mcam, vec3(x_move, y_move, zoom));
	
	/*mcam = rotate(mcam, thetaV, vec3(1, 0, 0));
	//mcam = rotate(mcam, -thetaH, vec3(0, 1, 0));
	
	mcam = translate(mcam, -camera);
	//mcam = scale(mcam, vec3(zoom + 1, zoom + 1, zoom + 1));
	//mcam = translate(mcam, vec3(0, 0, zoom));
	mcam = rotate(mcam, -thetaH, vec3(0, 1, 0));
	mcam = translate(mcam, vec3(x_move, y_move, zoom));*/
	
	//mcam = translate(mcam, -point);

	mcam *= translate(mat4(), vec3(x_move, y_move, zoom));
	mcam *= rotate(mat4(), thetaV, vec3(1, 0, 0));
	mcam *= rotate(mat4(), -thetaH, vec3(0, 1, 0));
	mcam *= translate(mat4(), - camera);
	mcam *= translate(mat4(), - point);

	//mcam = mcamComp(origin - camera, vec3(0, 1, 0), camera);

	if (part1){
		mat4 model;
		model = mat4();
		model = translate(model, vec3(0, 0, zoom));
		model = rotate(model, thetaV, vec3(1, 0, 0));
		model = rotate(model, -thetaH, vec3(0, 1, 0));

		vec3 points[] = { vec3(-1, 0, 0), vec3(-0.5, 1, 0), vec3(-0.5, 0, 0), vec3(0, 0, 0), vec3(0.5, 0, 0), vec3(0.5, -1, 0), vec3(1, 0, 0) };

		canvas.Clear();
		DrawCubePart1(mp*mcam*model);
		//DrawBezierCurve(points, 7);
	}
	else{
		//enables z-buffer
		glEnable(GL_DEPTH_TEST);
		glDepthFunc(GL_LESS);

		glClearColor(0.1f, 0.2f, 0.1f, 1.0f);//basic background colour

		//adjusts the uniforms based on calculations
		glUseProgram(programID);
		glBindVertexArray(VertexArrayID);
		glUniformMatrix4fv(MpBindingID, 1, GL_FALSE, &mp[0][0]);
		glUniformMatrix4fv(McamBindingID, 1, GL_FALSE, &mcam[0][0]);
		glUniform3fv(lightSourceBindingID, 1, &lightPos[0]);
		glUniform3fv(lightColourBindingID, 1, &lightColour[0]);
		glUniform3fv(cameraBindingID, 1, &camera[0]);
		glUniform1i(useNormalMapBindingID, USE_NORM_MAP);
		glUniform1i(redBindingID, red);
		glUniform1i(greenBindingID, green);
		glUniform1i(blueBindingID, blue);

		//clears old buffer data and draws the background
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		if (!USE_COLOUR) drawBackground();
		glClear(GL_DEPTH_BUFFER_BIT);//to keep in background

		//draws the terrain
		mat4 temp;
		temp = mat4();
		temp = translate(temp, vec3(-8, -1, -8));
		glUniform1i(isTerrainBindingID, true);
		useTexture(planet, normteximage3);
		drawTerrain(temp);
		glUniform1i(isTerrainBindingID, false);

		//first object
		mat4 model;
		model = mat4();
		/*model = translate(model, vec3(x_move, y_move, zoom));
		model = rotate(model, thetaV, vec3(1, 0, 0));
		model = rotate(model, -thetaH, vec3(0, 1, 0));*/
		model = translate(model, vec3(0, 2, 0));

		useTexture(sun, normteximage3);
		drawSphere(model);//can choose a sphere or a cube
		//drawCube(model);

		//second object
		mat4 model2 = scale(model, vec3(0.5, 0.5, 0.5));
		model2 = rotate(model2, timer, vec3(0, 1, 0));
		model2 = translate(model2, vec3(0, 0, -6));

		useTexture(planet, normteximage2);
		drawSphere(model2);//can choose a sphere or a cube
		//drawCube(model2);

		//third object
		mat4 model3 = scale(model2, vec3(0.5, 0.5, 0.5));
		model3 = rotate(model3, 5 * timer, vec3(0, 1, 0));
		model3 = translate(model3, vec3(0, 0, -4));

		useTexture(moon, normteximage);
		drawSphere(model3);//can choose a sphere or a cube
		//drawCube(model3);

		//Clean up the openGL context for other drawings
		glUseProgram(0);
		glBindVertexArray(0);
	}
}

//increases timer by 0.1 every frame
void OnTimer()
{
	timer += 0.1 * speed;
}

int main(int, char **){

    //links the call backs
    canvas.SetMouseMove(MouseMove);
    canvas.SetMouseButton(MouseButton);
    canvas.SetKeyPress(KeyPress);
    canvas.SetOnPaint(OnPaint);
    canvas.SetTimer(0.001, OnTimer);//trigger OnTimer every 0.1 second
	
	//initialization
	canvas.Initialize(width, height, "OpenGL Interactive Cube/Sphere");
	srand(seed);//sets the seed for the random numbers
	diamondSquare(0, 0, size, size, 128, 128);//runs the diamond square algorithm to get the hight map
	addPlaines();//adjusts the hight map to give a minimum depth
	genTerrain();//uses the hights to generate the vertex information needed to draw the terrain
	if (!part1) InitializeGL();
	canvas.Show();
    return 0;
}

