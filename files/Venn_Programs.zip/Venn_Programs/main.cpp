#define DUAL_DEGREE_MAX 20 // max degree of a vertex in the dual graph
#define DUAL_SIZE_MAX 64 // max size of the dual graph
#define EMPTY -1 // empty value
#define NUM_CORES 8 // number of instances to run on
#define LONG_OUT false // for long output use true

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <ctime>
#include "dual.h"
#include "hamilton.h"

using namespace std;

int main(int argc, char* argv[]){
	clock_t startTime = clock();// start timer
	// needed variables
	int num_vert, degree, vert, max_face_size, core_num, graph_num, failed_counter;
	core_num = -1;
	graph_num = -1;
	failed_counter = 0;
	// get the core number to run on
	if (argc == 2){
		core_num = atoi(argv[1]);
		if (core_num != -1) printf("exicuting on venns %d %% %d\n", core_num, NUM_CORES);
		else printf("exicuting on all venns\n");
	}
	// Get get one Venn at a time and try to find a Hamiltonian cycle
	while (cin >> num_vert){
		int graph[num_vert][4];
		for (int i = 0; i < num_vert; i++){
			std::cin >> degree;
			for (int j = 0; j < degree; j++){
				std::cin >> vert;
				graph[i][j] = vert;
			}
		}
		graph_num++;
		// check if the Venn is one to calculate
		if (core_num == -1 || (graph_num % NUM_CORES) == core_num){
			if (LONG_OUT) printf("Venn %d:\n", graph_num+1);
			//print_graph(graph, num_vert);// prints the Venn 
			int dual[DUAL_SIZE_MAX][DUAL_DEGREE_MAX];// holds the dual graph
			int dual_size;// number of vertices in the dual
			int faces[num_vert][4];// face number the edge is a part of
			get_dual(faces, dual, graph, num_vert, &dual_size, &max_face_size);// find the dual graph
			// code to print the dual
			/*printf("dual:\n");
			for (int i = 0; i < dual_size; i++){
				printf("%d: ",i);
				for (int j = 1; j <= dual[i][0]; j++){
					printf("%d ",dual[i][j]);
					//printf("n%d/n%d, ",i,dual[i][j]);
				}
				printf("\n");
			}
			printf("\n");*/
			//printf("%d\n",dual_size);
			int cycle[DUAL_SIZE_MAX];// holds the main cycle
			init_array(cycle, DUAL_SIZE_MAX);// sets all values to EMPTY
			hamilton_cycle(dual, graph, faces, cycle, dual_size, num_vert, &failed_counter);// try to find a Hamiltonian cycle
			if (LONG_OUT) printf("\n");
		}
		
	}
	//printf("%d\n",max_face_size);// the size of the largest face

	// end the timer
	clock_t endTime = clock();
	clock_t clockTicksTaken = endTime - startTime;
	double timeInSeconds = clockTicksTaken / (double) CLOCKS_PER_SEC;
	printf("The program failed to find a H-path %d times.\n", failed_counter);// say how many Venns it could not find Hamiltonian cycles in

	// prints run time
	if (core_num == -1) printf("The program exited normaly in %f seconds.\n", timeInSeconds);
	else printf("The program exited normaly on core %d in %f seconds.\n", core_num, timeInSeconds);
	return 0;
}






