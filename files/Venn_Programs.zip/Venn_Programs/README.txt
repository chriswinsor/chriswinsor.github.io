Program description:
    This program takes in Venn diagrams and tries to find a Hamilton cycle in its dual graph using Venn's construction.
    All simple 5-Venns are provided as default input and output is sent to the output folder.

How to Run:
    Type ./run_venn.sh in a console where the file is located. Edit FILE_NAME in run_venn.sh to change
    the file path to the file you want to run on. For large files, it is sugested to change SINGLE_CORE 
    to 0 and the list to the number of cores on your computer. Default core count is 8.

Files Included:
    main.cpp: the location of the main function of the program.
    dual.h: has all the functions for finding the dual graph.
    hamilton.h: has all functions for finding a Hamilton cycle in the dual graph.
    run_venn.sh: shell script for compiling and running the program.
    README.txt: the file you should be reading now.
    5venn.txt: default input file. Has all simple 5-Venns included.
    6venn_output.txt: the results of running the program on all simple 6-Venns.
    output/: folder for all output files from the program.
