
// prints a Venn
void print_graph(int graph[][4], int num_vert){
	for (int i = 0; i < num_vert; i++){
		printf("%d:",i);
		for (int j = 0; j < 4; j++){
			printf("%d ",graph[i][j]);
		}
		printf("\n");
	}
	printf("\n");
}
// sets the values of graph to EMPTY
void init_graph(int graph[][4], int num_vert){
	for (int i = 0; i < num_vert; i++){
		for (int j = 0; j < 4; j++){
			graph[i][j] = EMPTY;
		}
	}
}
// finds the next unused edge for the face walking algorithm
bool next_face(int used[][4], int graph[][4], int num_vert, int *v1, int *v2, int *pos_v2){
	for (int i = 0; i < num_vert; i++){
		for (int j = 0; j < 4; j++){
			if (used[i][j] == EMPTY){
				*v1 = i;
				*v2 = graph[i][j];
				*pos_v2 = j;
				return true;
			}
		}
	}
	return false;
}
// finds the dual graph
void get_dual(int faces[][4], int dual[DUAL_SIZE_MAX][DUAL_DEGREE_MAX], int graph[][4], int num_vert, int *dual_size, int *max_face_size){
	
	int used[num_vert][4];// 1 if edge used and EMPTY if not
	int face_num = 0;
	
	int v1 = 0;// start of edge
	int v2 = graph[v1][0];// end of edge
	int pos_v2 = 0;// where v2 is in v1's list
	
	int face_size = 0;
	
	init_graph(faces, num_vert);// set to EMPTY
	// walk faces and store face value
	while (next_face(faces, graph, num_vert, &v1, &v2, &pos_v2)){
		while (faces[v1][pos_v2] == EMPTY){
			faces[v1][pos_v2] = face_num;
			face_size++;
			for (int i = 0; i < 4; i++){
				if (graph[v2][i] == v1){// gets the next edge of the face
					v1 = v2;
					v2 = graph[v2][(i+1)%4];
					pos_v2 = (i+1)%4;
					break;
				}
			}
		}
		if (face_size > *max_face_size) *max_face_size = face_size;// increase the max face size if the face is larger
		face_size = 0;
		face_num++;
	}
	
	// walk faces again to get edges of dual
	*dual_size = face_num;
	v1 = 0;
	v2 = graph[v1][0];
	pos_v2 = 0;
	face_num = 0;
	face_size = 0;
	init_graph(used, num_vert);
	// walk faces and store face value
	while (next_face(used, graph, num_vert, &v1, &v2, &pos_v2)){
		int count = 1;
		dual[face_num][0] = 0;
		while (used[v1][pos_v2] == EMPTY){
			used[v1][pos_v2] = face_num;
			face_size++;
			for (int i = 0; i < 4; i++){
				if (graph[v2][i] == v1){
					dual[face_num][count] = faces[v2][i];
					dual[face_num][0] = count;
					count++;
					v1 = v2;
					v2 = graph[v2][(i+1)%4];
					pos_v2 = (i+1)%4;
					break;
				}
			}
		}
		face_size = 0;
		face_num++;
	}
}
