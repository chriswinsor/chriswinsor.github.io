FILE_NAME="5venn.txt" # path to the input file
SINGLE_CORE='1' # 0 means use all cores, 1 means use one core
echo "compiling."
g++ main.cpp
if [ "$SINGLE_CORE" -eq "1" ]; then
    echo "running on one core"
    ./a.out -1 < $FILE_NAME > output/out.txt
fi 
if [ "$SINGLE_CORE" -eq "0" ]; then
    for i in 0 1 2 3 4 5 6 7; do
      echo "running on core $i"
      ./a.out $i < $FILE_NAME > output/out$i.txt& # run in the backgrouned
    done
fi

echo "finished."