// sets the array to EMPTY
void init_array(int array[], int num_vert){
	for (int i = 0; i < num_vert; i++){
		array[i] = EMPTY;
	}
}
// finds the next edge not used in a curve
bool get_starting_edge(int graph[][4], int used[][4], int graph_size, int *start_e1, int *start_e2){
	for (int i = 0; i < graph_size; i++){
		for (int j = 0; j < 4; j++){
			if (used[i][j] != 1){
				*start_e1 = i;
				*start_e2 = graph[i][j];
				return true;
			}
		}
	}
	return false;
}
// walks around a curve and creates the main cycle surounding the curve
bool curve_walk(int graph[][4], int used[][4], int graph_size, int *start_e1, int *start_e2){
	bool found = get_starting_edge(graph, used, graph_size, start_e1, start_e2);// finds an edge of a curve that hasent been walked yet
	if (!found) return false;// stops if all curves have been walked
	int v1 = *start_e1;
	int v2 = *start_e2;
	bool init = true;
	int v1_temp, v2_temp;
	// followes one curve
	while(v1 != *start_e1 || init == true){
		for (int i = 0; i < 4; i++){
			if (graph[v1][i] == v2){
				used[v1][i] = 1;// markes one direction of the edge as used
			}
			if (graph[v2][i] == v1){
				used[v2][i] = 1;// markes the other direction of the edge as used
				// update to the next edge of the curve
				v1_temp = v2;
				v2_temp = graph[v2][(i+2)%4];
			}
		}
		v1 = v1_temp;
		v2 = v2_temp;
		if (init == true){
			init = false;
		}
	}
	return true;
}
// finds the path in the dual that correpondes with Euler's constuction for expanding Venn diagrams
void Venn(int graph[][4], int faces[][4], int cycle[], int start_e1, int start_e2){
	int v1 = start_e1;
	int v2 = start_e2;
	int f1, f2;
	bool init = true;

	// followes one curve and connects the faces on either side of the curve to form one big cycle
	while(v1 != start_e1 || init == true){
		int v1_temp, v2_temp;
		for (int i = 0; i < 4; i++){
			if (graph[v1][i] == v2){
				if (init != true) cycle[f1] = faces[v1][i];
				f1 = faces[v1][i];// get the face on the up side of the edge
			}
			if (graph[v2][i] == v1){
				if (init != true) cycle[faces[v2][i]] = f2;
				f2 = faces[v2][i];// get the face on the down side of the edge
				
				// update to the next edge of the curve
				v1_temp = v2;
				v2_temp = graph[v2][(i+2)%4];
			}
		}
		v1 = v1_temp;
		v2 = v2_temp;
		if (init == true){
			cycle[f2] = f1;
			init = false;
		}
	}
	cycle[f1] = f2;
	if (LONG_OUT){
		int i = f1;
		printf("Venn = (%d", i);
		i = cycle[i];
		while (i != f1){
			printf(", %d", i);
			i = cycle[i];
		}
		printf(")\n");
	}
}
void BFS(int graph[][DUAL_DEGREE_MAX], int used[DUAL_SIZE_MAX], int component[DUAL_SIZE_MAX], int start_v){
	// initialize queue
	int queue[DUAL_SIZE_MAX];
	int q_start = 0;
	int q_end = 0;
	int q_used[DUAL_SIZE_MAX];
	init_array(q_used, DUAL_SIZE_MAX);

	// insert starting vertex
	queue[q_end] = start_v;
	q_end++;
	q_used[start_v] = 1;
	int c_pos = 1;
	component[0] = 0;

	while (q_start != q_end){
		// dequeue start
		int v = queue[q_start];
		q_start++;
		
		component[c_pos] = v;
		c_pos++;
		component[0]++;

		// queue adjacent verticies
		for (int i = 1; i <= graph[v][0]; i++){
			if (used[graph[v][i]] != 1){
				if(q_used[graph[v][i]] != 1){
					queue[q_end] = graph[v][i];
					q_end++;
					q_used[graph[v][i]] = 1;
				}
			}
		}
	}
	if (LONG_OUT){
		printf("component = (");
		for (int i = 1; i <= component[0]; i++){
			printf("%d ", component[i]);
		}
		printf(")\n");
	}
	
}
// recursive function of hamilton_path
bool hamilton_path_rec(int graph[][DUAL_DEGREE_MAX], int used[DUAL_SIZE_MAX], int component[DUAL_SIZE_MAX], int cycle[],int path[], int vert, int start, int depth){
	// check if depth is equal to component[0] and see if the path can be added into the cycle 0
	if (depth == component[0]){
		// try to connect the path to the main cycle to get a bigger cycle
		for (int i = 1; i <= graph[start][0]; i++){
			for (int j = 1; j <= graph[vert][0]; j++){
				// check if a neighbour of start is next to a neighbour of vert in the cycle
				if (cycle[graph[start][i]] == graph[vert][j]){
					cycle[graph[start][i]] = start;
					if (LONG_OUT) printf("connected by (%d, %d)\n", graph[start][i], graph[vert][j]);
					// add path to cycle
					int v_path = start;
					cycle[v_path] = path[v_path];
					v_path = path[v_path];
					int counter = 1;
					while (counter != depth){
						cycle[v_path] = path[v_path];
						v_path = path[v_path];
						counter++;
					}
					cycle[vert] = graph[vert][j];
					return true;
				}
			}
		}
		return false;
	}
	// extend path if possible
	for (int i = 1; i <= graph[vert][0]; i++){// check the neighbour's to find the next possible vertex in the path
	    if (used[graph[vert][i]] != 1){// only check neighbour's that haven't been seen yet
			used[graph[vert][i]] = 1;// put it in the path
			path[vert] = graph[vert][i];
			bool found = hamilton_path_rec(graph, used, component, cycle, path, graph[vert][i], start, depth + 1);// try extending the path
			if (found) return true;
			used[graph[vert][i]] = EMPTY;// didn't find the path using this vertex so try the next
			path[vert] = EMPTY;
		}
	}
	return false;
}
// uses DFS to find a Hamilton path
void hamilton_path(int graph[][DUAL_DEGREE_MAX], int used[DUAL_SIZE_MAX], int component[DUAL_SIZE_MAX], int cycle[]){
	// first check if it is just one vertex and deal with it 
	if (component[0] == 1){
		int v = component[1];
		for (int i = 1; i <= graph[v][0]; i++){
			for (int j = 1; j <= graph[v][0]; j++){
				if (cycle[graph[v][i]] == graph[v][j]){
					cycle[graph[v][i]] = v;
					cycle[v] = graph[v][j];
					return;
				}
			}
		}
	}
	int depth = 0;
	int path[DUAL_SIZE_MAX];
	init_array(path, DUAL_SIZE_MAX);
	for (int i = 1; i <= component[0]; i++){// start potential path with each vertex in the connected component
		used[component[i]] = 1;
		for (int j = 1; j <= graph[component[i]][0]; j++){// check the neighbour's to find the next possible vertex in the path
			int v = graph[component[i]][j];
		    if (used[v] != 1){// only check neighbour's that haven't been seen yet
				used[v] = 1;// put it in the path
				path[component[i]] = v;
				bool found = hamilton_path_rec(graph, used, component, cycle, path, v, component[i], depth + 2);// try extending the path
				if (found) return;// stops when found
				used[v] = EMPTY;// didn't find the path using this vertex so try the next
				path[component[i]] = EMPTY;
		    }
		}
		used[component[i]] = EMPTY;
	}
}
// tries to find a Hamilton cycle
void hamilton_cycle(int dual[DUAL_SIZE_MAX][DUAL_DEGREE_MAX], int graph[][4], int faces[][4], int cycle[], int dual_size, int graph_size, int *failed_counter){
	int used[DUAL_SIZE_MAX];
	int curves_used[graph_size][4];
	init_graph(curves_used, graph_size);
	int e1, e2;// an edge of one curve
	// try for each curve
	while (curve_walk(graph, curves_used, graph_size, &e1, &e2)){
		init_array(used, DUAL_SIZE_MAX);// reset for each loop
		init_array(cycle, DUAL_SIZE_MAX);// reset for each loop
		if (LONG_OUT) printf("trying curve with (%d, %d)\n", e1, e2);
		Venn(graph, faces, cycle, e1, e2);// get the main cycle for this curve 
		// set each of the edges in the main cycle to used
		for (int i = 0; i < DUAL_SIZE_MAX; i++){
			if (cycle[i] != -1) used[i] = 1;
		}
		// go through every unused vertex and try to connect the component it is in
		for (int i = 0; i < dual_size; i++){
			if (used[i] != 1){
				int component[DUAL_SIZE_MAX];// list of the vertices in the component
				BFS(dual,used, component, i);// fill the component list
				hamilton_path(dual, used, component, cycle);// try to connect the component to the main cycle
			}
		}
		// find the length of the cycle
		int i = 0;
		i = cycle[i];
		int j = 1;
		if (LONG_OUT) printf("longest cycle = (%d", 0);
		while (i != 0 && j < DUAL_SIZE_MAX){
			if (LONG_OUT) printf(", %d", i);
			i = cycle[i];
			j++;
		}
		if (LONG_OUT) printf(") using %d verticies\n", j);
		if (j == dual_size){
			// uncomment to print the Hamilton cycle
			/*int i2 = 0;
			i2 = cycle[i2];
			int j2 = 1;
			printf("h_cycle = (%d", 0);
			while (i2 != 0 && j2 < DUAL_SIZE_MAX){
				//printf(", %d", i2);
				i2 = cycle[i2];
				j2++;
			}
			printf(") using all %d verticies\n", j2);*/
			return;
		} 
	}
	// the algorithm failed to find a Hamilton cycle if it gets here
	if (LONG_OUT) printf("Did not find a h_cycle");
	int temp = *failed_counter;
	*failed_counter = temp+1;
}